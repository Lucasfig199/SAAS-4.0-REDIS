﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import copy
import re
import json
import time
import uuid
import queue
import threading
import secrets
import asyncio
import mimetypes
import sqlite3
import random
from pathlib import Path
from collections import deque
import hmac
import hashlib
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

import requests
from flask import Flask, request, jsonify, send_from_directory, send_file

try:
    import redis  # type: ignore
except Exception:
    redis = None

from telethon import TelegramClient, events
from telethon.tl.types import DocumentAttributeAnimated, InputPeerUser
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneCodeInvalidError,
    PhoneNumberInvalidError,
    ApiIdInvalidError,
    FloodWaitError,
    AuthKeyUnregisteredError,
    SessionRevokedError,
)


# =========================================================
# Paths
# =========================================================
PROJECT_ROOT = Path(__file__).resolve().parent
BASE_DIR = str(PROJECT_ROOT)
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
FINGERPRINTS_PATH = os.path.join(BASE_DIR, "fingerprints.json")
SESSIONS_DIR = os.path.join(BASE_DIR, "sessions")
STATIC_DIR = os.path.join(BASE_DIR, "static")
MEDIA_DIR_DEFAULT = "tmp_media"
MEDIA_TTL_SECONDS_DEFAULT = 900
MEDIA_STORE_DIR_DEFAULT = "media_store"
MEDIA_STORE_TTL_SECONDS_DEFAULT = 86400
MEDIA_STORE_TOUCH_ON_USE_DEFAULT = True
MAX_REMOTE_FILE_BYTES = 25 * 1024 * 1024
REMOTE_DOWNLOAD_TIMEOUT_SECONDS = 20
CONTENT_TYPE_EXT = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "video/mp4": ".mp4",
    "video/quicktime": ".mov",
    "audio/ogg": ".ogg",
    "audio/opus": ".ogg",
    "audio/mpeg": ".mp3",
    "audio/mp3": ".mp3",
    "application/pdf": ".pdf",
}

os.makedirs(SESSIONS_DIR, exist_ok=True)
os.makedirs(STATIC_DIR, exist_ok=True)
DATA_DIR = PROJECT_ROOT / "data"
SEND_DB_PATH = DATA_DIR / "send_queue.db"

COOKIE_NAME = "tg_saas_session"
COOKIE_MAX_AGE = 60 * 60 * 24 * 7  # 7 dias

ID_RE = re.compile(r"^[a-zA-Z0-9_\-]{2,64}$")


# =========================================================
# Flask
# =========================================================
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="/static")




@app.before_request
def guard_api_explorer():
    if request.path == "/static/api_explorer.html":
        cfg = load_config()
        if not is_logged_in(cfg, request):
            return jsonify({"ok": False, "error": "unauthorized"}), 401


@app.after_request
def add_no_cache_headers(resp):
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


# =========================================================
# Utils
# =========================================================
_config_lock = threading.Lock()
_job_lock = threading.Lock()
_health_lock = threading.Lock()
_health_cache: Dict[str, Dict[str, Any]] = {}
HEALTH_TTL_SEC = 45
_media_lock = threading.Lock()
_media_cache: Dict[str, Dict[str, Any]] = {}
_listener_lock = threading.Lock()
_listeners: Dict[str, Dict[str, Any]] = {}
_listener_starting: set = set()
_listener_stats_lock = threading.Lock()
_listener_stats: Dict[str, Dict[str, int]] = {}
_listener_health_lock = threading.Lock()
_listener_health: Dict[str, Dict[str, Any]] = {}
_send_db_lock = threading.Lock()
_send_locks_lock = threading.Lock()
_send_locks: Dict[str, threading.Lock] = {}
_debug_lock = threading.Lock()
_debug_logs: "deque[str]" = deque(maxlen=200)

LISTENER_DEFAULTS: Dict[str, bool] = {
    "enabled": True,
    "forward_private": True,
    "forward_groups": True,
    "forward_channels": False,
    "download_media_private": True,
    "download_media_groups": False,
    "download_media_channels": False,
}

LISTENER_RESTART_BACKOFF = [10, 30, 120, 300, 600]
WEBHOOK_WORKERS = max(1, int(os.getenv("TGS_WEBHOOK_WORKERS", "4")))
LISTENER_WORKERS = max(1, int(os.getenv("TGS_LISTENER_WORKERS", "2")))
SEND_DISPATCH_INTERVAL_SEC = 1


def now_epoch() -> int:
    return int(time.time())


def _log_debug(msg: str) -> None:
    ts = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    line = f"[{ts}] {msg}"
    with _debug_lock:
        _debug_logs.append(line)
    print(line)


def read_json(path: str, default: Any) -> Any:
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f)
        except Exception:
            return default

def read_json_with_status(path: str, default: Any) -> tuple[Any, str]:
    if not os.path.exists(path):
        return default, "missing"
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f), "ok"
    except Exception:
        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                return json.load(f), "ok"
        except Exception:
            return default, "invalid"


def write_json_atomic(path: str, data: Any) -> None:
    tmp = f"{path}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _media_dir_abs() -> str:
    cfg = load_config()
    rel_dir = str(cfg.get("media", {}).get("dir") or MEDIA_DIR_DEFAULT).strip() or MEDIA_DIR_DEFAULT
    if os.path.isabs(rel_dir):
        abs_dir = Path(rel_dir)
    else:
        abs_dir = PROJECT_ROOT / rel_dir
    abs_dir.mkdir(parents=True, exist_ok=True)
    return str(abs_dir)


def _media_store_dir_abs() -> str:
    cfg = load_config()
    rel_dir = str(cfg.get("media_store", {}).get("dir") or MEDIA_STORE_DIR_DEFAULT).strip() or MEDIA_STORE_DIR_DEFAULT
    if os.path.isabs(rel_dir):
        abs_dir = Path(rel_dir)
    else:
        abs_dir = PROJECT_ROOT / rel_dir
    abs_dir.mkdir(parents=True, exist_ok=True)
    return str(abs_dir)


def _ensure_dirs() -> None:
    _media_dir_abs()
    if _media_store_enabled():
        _media_store_dir_abs()


def _media_ttl_seconds() -> int:
    cfg = load_config()
    try:
        ttl = int(cfg.get("media", {}).get("ttl_seconds") or MEDIA_TTL_SECONDS_DEFAULT)
    except Exception:
        ttl = MEDIA_TTL_SECONDS_DEFAULT
    return max(60, ttl)


def _media_store_ttl_seconds() -> int:
    cfg = load_config()
    try:
        ttl = int(cfg.get("media_store", {}).get("ttl_seconds") or MEDIA_STORE_TTL_SECONDS_DEFAULT)
    except Exception:
        ttl = MEDIA_STORE_TTL_SECONDS_DEFAULT
    return max(300, ttl)


def _media_store_enabled() -> bool:
    cfg = load_config()
    return bool(cfg.get("media_store", {}).get("enabled", True))


def _media_store_touch_on_use() -> bool:
    cfg = load_config()
    return bool(cfg.get("media_store", {}).get("touch_on_use", True))


def _is_within_dir(path: str, base: str) -> bool:
    try:
        return os.path.commonpath([os.path.abspath(path), os.path.abspath(base)]) == os.path.abspath(base)
    except Exception:
        return False


def _media_path_safe(path: str) -> bool:
    return _is_within_dir(path, _media_dir_abs())


def _media_store_path_safe(path: str) -> bool:
    return _is_within_dir(path, _media_store_dir_abs())

def _allowed_file_path(path: str) -> bool:
    if not path:
        return False
    try:
        abs_path = os.path.abspath(path)
    except Exception:
        return False
    if _media_path_safe(abs_path):
        return True
    if _media_store_enabled() and _media_store_path_safe(abs_path):
        return True
    return False


def _touch(path: str) -> None:
    try:
        os.utime(path, None)
        _log_debug(f"media touch path={os.path.basename(path)}")
    except Exception:
        pass


def cleanup_media_dir() -> Dict[str, int]:
    media_dir = _media_dir_abs()
    ttl = _media_ttl_seconds()
    scanned = 0
    removed = 0
    errors = 0
    now = now_epoch()

    try:
        for entry in os.scandir(media_dir):
            if not entry.is_file():
                continue
            scanned += 1
            try:
                age = now - int(entry.stat().st_mtime)
            except Exception:
                errors += 1
                continue
            if age > ttl:
                if not _media_path_safe(entry.path):
                    errors += 1
                    _log_debug(f"cleanup skip unsafe file={entry.name}")
                    continue
                try:
                    os.remove(entry.path)
                    removed += 1
                except Exception as e:
                    errors += 1
                    _log_debug(f"cleanup error file={entry.name} error={str(e)}")
    except Exception as e:
        errors += 1
        _log_debug(f"cleanup scan error dir={media_dir} error={str(e)}")

    _log_debug(f"cleanup scanned={scanned} removed={removed} errors={errors}")
    return {"scanned": scanned, "removed": removed, "errors": errors}


def cleanup_media_store() -> Dict[str, int]:
    if not _media_store_enabled():
        return {"scanned": 0, "removed": 0, "errors": 0}
    media_dir = _media_store_dir_abs()
    ttl = _media_store_ttl_seconds()
    scanned = 0
    removed = 0
    errors = 0
    now = now_epoch()

    try:
        for entry in os.scandir(media_dir):
            if not entry.is_file():
                continue
            scanned += 1
            try:
                age = now - int(entry.stat().st_mtime)
            except Exception:
                errors += 1
                continue
            if age > ttl:
                if not _media_store_path_safe(entry.path):
                    errors += 1
                    _log_debug(f"store cleanup skip unsafe file={entry.name}")
                    continue
                try:
                    os.remove(entry.path)
                    removed += 1
                except Exception as e:
                    errors += 1
                    _log_debug(f"store cleanup error file={entry.name} error={str(e)}")
    except Exception as e:
        errors += 1
        _log_debug(f"store cleanup scan error dir={media_dir} error={str(e)}")

    _log_debug(f"store cleanup scanned={scanned} removed={removed} errors={errors}")
    return {"scanned": scanned, "removed": removed, "errors": errors}

def _media_cache_get(media_id: str) -> Optional[Dict[str, Any]]:
    with _media_lock:
        item = _media_cache.get(media_id)
        if not item:
            if media_id.startswith("store_"):
                url_hash = media_id.replace("store_", "", 1)
                store_dir = _media_store_dir_abs()
                try:
                    for entry in os.scandir(store_dir):
                        if entry.is_file() and entry.name.startswith(f"url_{url_hash}"):
                            payload = {
                                "media_id": media_id,
                                "path": entry.path,
                                "mime": mimetypes.guess_type(entry.path)[0] or "application/octet-stream",
                                "created_at": now_epoch(),
                            }
                            _media_cache[media_id] = dict(payload)
                            return dict(payload)
                except Exception:
                    return None
            return None
        path = item.get("path")
        if path and not os.path.exists(path):
            _media_cache.pop(media_id, None)
            return None
        if media_id.startswith("store_"):
            return dict(item)
        if (now_epoch() - int(item.get("created_at") or 0)) <= _media_ttl_seconds():
            return dict(item)
        return None


def _media_cache_set(media_id: str, payload: Dict[str, Any]) -> None:
    with _media_lock:
        _media_cache[media_id] = dict(payload)


def _media_cache_drop(media_id: str) -> None:
    with _media_lock:
        _media_cache.pop(media_id, None)


def _media_gc_worker():
    while True:
        time.sleep(60)
        cleanup_media_dir()
        to_remove: List[Dict[str, Optional[str]]] = []
        now = now_epoch()
        with _media_lock:
            for mid, info in _media_cache.items():
                if mid.startswith("store_"):
                    continue
                created_at = int(info.get("created_at") or 0)
                if now - created_at > _media_ttl_seconds():
                    to_remove.append({"media_id": mid, "path": info.get("path")})
        for item in to_remove:
            mid = item.get("media_id")
            path = item.get("path")
            if path and os.path.exists(path) and _media_path_safe(path):
                try:
                    os.remove(path)
                    _log_debug(f"cleanup removed cached file={os.path.basename(path)}")
                except Exception:
                    pass
            if mid:
                _media_cache_drop(mid)


def _media_store_gc_worker():
    while True:
        time.sleep(300)
        cleanup_media_store()




def _normalize_listener_config(lc: Any) -> Dict[str, bool]:
    out = dict(LISTENER_DEFAULTS)
    if not isinstance(lc, dict):
        return out

    legacy_private_only = lc.get("private_only")
    legacy_ignore_groups = lc.get("ignore_groups")
    legacy_ignore_channels = lc.get("ignore_channels")

    if legacy_private_only is not None:
        if bool(legacy_private_only):
            out["forward_groups"] = False
            out["forward_channels"] = False
            out["download_media_groups"] = False
            out["download_media_channels"] = False
        else:
            if legacy_ignore_groups is not None:
                val = not bool(legacy_ignore_groups)
                out["forward_groups"] = val
                out["download_media_groups"] = val
            if legacy_ignore_channels is not None:
                val = not bool(legacy_ignore_channels)
                out["forward_channels"] = val
                out["download_media_channels"] = val
    else:
        if legacy_ignore_groups is not None:
            val = not bool(legacy_ignore_groups)
            out["forward_groups"] = val
            out["download_media_groups"] = val
        if legacy_ignore_channels is not None:
            val = not bool(legacy_ignore_channels)
            out["forward_channels"] = val
            out["download_media_channels"] = val

    for key in out.keys():
        if key in lc:
            out[key] = bool(lc.get(key))

    return out


def ensure_config_defaults(cfg: Dict[str, Any]) -> Dict[str, Any]:
    cfg.setdefault("server", {})
    cfg["server"].setdefault("host", "0.0.0.0")
    cfg["server"].setdefault("port", 5000)
    cfg["server"].setdefault("cors_origins", [])

    cfg.setdefault("admin", {})
    cfg["admin"].setdefault("user", "admin")
    cfg["admin"].setdefault("pass_plain", "SUA_SENHA_AQUI")
    if not cfg["admin"].get("session_secret"):
        cfg["admin"]["session_secret"] = secrets.token_urlsafe(48)

    cfg.setdefault("api", {})
    if not cfg["api"].get("bearer_token"):
        cfg["api"]["bearer_token"] = secrets.token_urlsafe(48)
    cfg["api"].setdefault("require_bearer_on_api", True)

    cfg.setdefault("redis", {})
    cfg["redis"].setdefault("enabled", False)
    cfg["redis"].setdefault("host", "127.0.0.1")
    cfg["redis"].setdefault("port", 6379)
    cfg["redis"].setdefault("db", 0)
    cfg["redis"].setdefault("password", "")
    cfg["redis"].setdefault("prefix", "tgs")

    # webhook (legado/global)
    cfg.setdefault("webhook", {})
    wh = cfg["webhook"]
    if "timeout_sec" not in wh and "timeout_seconds" in wh:
        wh["timeout_sec"] = wh["timeout_seconds"]
    if "max_retries" not in wh and "retries" in wh:
        wh["max_retries"] = wh["retries"]
    if "retry_delay_sec" not in wh and "retry_delay_seconds" in wh:
        wh["retry_delay_sec"] = wh["retry_delay_seconds"]

    wh.setdefault("enabled", True)  # legacy config uses "webhook" as global
    wh.setdefault("default_url", "")
    wh.setdefault("timeout_sec", 10)
    wh.setdefault("max_retries", 3)
    wh.setdefault("retry_delay_sec", 2)
    wh.setdefault("queue_delay_threshold", 10)
    wh.setdefault("queue_delay_seconds", 1.5)

    cfg.setdefault("fingerprints", {})
    cfg["fingerprints"].setdefault("default_id", None)
    cfg["fingerprints"].setdefault("profiles", [])

    cfg.setdefault("media", {})
    cfg["media"].setdefault("dir", MEDIA_DIR_DEFAULT)
    cfg["media"].setdefault("ttl_seconds", MEDIA_TTL_SECONDS_DEFAULT)

    cfg.setdefault("media_store", {})
    cfg["media_store"].setdefault("enabled", True)
    cfg["media_store"].setdefault("dir", MEDIA_STORE_DIR_DEFAULT)
    cfg["media_store"].setdefault("ttl_seconds", MEDIA_STORE_TTL_SECONDS_DEFAULT)
    cfg["media_store"].setdefault("touch_on_use", MEDIA_STORE_TOUCH_ON_USE_DEFAULT)

    cfg.setdefault("send", {})
    cfg["send"].setdefault("backlog_limit", 20)
    cfg["send"].setdefault("ready_threshold", 10)
    cfg["send"].setdefault("max_queue_per_account", 5000)
    cfg["send"].setdefault("send_interval_sec", 2)
    cfg["send"].setdefault("job_ttl_seconds", 7200)
    cfg["send"].setdefault("cleanup_after_seconds", 172800)
    cfg["send"].setdefault("pause_jitter_min_sec", 60)
    cfg["send"].setdefault("pause_jitter_max_sec", 300)

    cfg["listener"] = _normalize_listener_config(cfg.get("listener", {}))

    return cfg


def load_config() -> Dict[str, Any]:
    with _config_lock:
        raw, status = read_json_with_status(CONFIG_PATH, {})
        cfg = ensure_config_defaults(copy.deepcopy(raw))
        if status == "ok":
            try:
                write_json_atomic(f"{CONFIG_PATH}.bak", raw)
            except Exception:
                pass
            if cfg != raw:
                write_json_atomic(CONFIG_PATH, cfg)
        elif status == "missing":
            write_json_atomic(CONFIG_PATH, cfg)
        else:
            backup, bstatus = read_json_with_status(f"{CONFIG_PATH}.bak", {})
            if bstatus == "ok":
                cfg = ensure_config_defaults(copy.deepcopy(backup))
            else:
                cfg = ensure_config_defaults({})
        return cfg

def save_config(cfg: Dict[str, Any]) -> None:
    with _config_lock:
        write_json_atomic(CONFIG_PATH, cfg)
        try:
            write_json_atomic(f"{CONFIG_PATH}.bak", cfg)
        except Exception:
            pass


# =========================================================
# Redis helpers
# =========================================================
_redis_lock = threading.Lock()
_redis_client_cache = None
_redis_client_ok: Optional[bool] = None


def _redis_cfg() -> Dict[str, Any]:
    cfg = load_config()
    rcfg = cfg.get("redis", {})
    return rcfg if isinstance(rcfg, dict) else {}


def _redis_prefix() -> str:
    prefix = str(_redis_cfg().get("prefix") or "tgs").strip()
    return prefix or "tgs"


def _redis_key(*parts: str) -> str:
    return f"{_redis_prefix()}:{':'.join(parts)}"


def _redis_enabled() -> bool:
    return bool(_redis_cfg().get("enabled")) and redis is not None


def _redis_client():
    global _redis_client_cache, _redis_client_ok
    if not _redis_enabled():
        return None
    with _redis_lock:
        if _redis_client_cache is not None and _redis_client_ok:
            return _redis_client_cache
        rcfg = _redis_cfg()
        try:
            client = redis.Redis(
                host=str(rcfg.get("host") or "127.0.0.1"),
                port=int(rcfg.get("port") or 6379),
                db=int(rcfg.get("db") or 0),
                password=str(rcfg.get("password") or "") or None,
                decode_responses=True,
                socket_timeout=10,
                socket_connect_timeout=5,
                retry_on_timeout=True,
            )
            client.ping()
            _redis_client_cache = client
            _redis_client_ok = True
            return client
        except Exception as e:
            _redis_client_cache = None
            _redis_client_ok = False
            _log_debug(f"redis_unavailable error={str(e)}")
            return None

def _parse_bool(val: Any) -> Optional[bool]:
    if isinstance(val, bool):
        return val
    if isinstance(val, str):
        raw = val.strip().lower()
        if raw in ("1", "true", "yes", "on"):
            return True
        if raw in ("0", "false", "no", "off"):
            return False
    return None


def get_listener_cfg() -> Dict[str, bool]:
    cfg = load_config()
    return _normalize_listener_config(cfg.get("listener", {}))


def chat_kind(event) -> str:
    if bool(getattr(event, "is_private", False)):
        return "private"
    if bool(getattr(event, "is_group", False)):
        return "group"
    if bool(getattr(event, "is_channel", False)):
        return "channel"
    return "private"


def should_forward(kind: str, cfg: Dict[str, bool]) -> bool:
    if kind == "private":
        return bool(cfg.get("forward_private", True))
    if kind == "group":
        return bool(cfg.get("forward_groups", True))
    if kind == "channel":
        return bool(cfg.get("forward_channels", False))
    return False


def should_download_media(kind: str, cfg: Dict[str, bool]) -> bool:
    if kind == "private":
        return bool(cfg.get("download_media_private", True))
    if kind == "group":
        return bool(cfg.get("download_media_groups", False))
    if kind == "channel":
        return bool(cfg.get("download_media_channels", False))
    return False


def _resolve_peer_for_send(acc: Dict[str, Any], chat_id: Any) -> Any:
    if chat_id is None:
        return chat_id
    if isinstance(chat_id, str):
        raw = chat_id.strip()
        if not raw or raw.startswith("@"):
            return chat_id
        try:
            chat_id = int(raw)
        except Exception:
            return chat_id
    if isinstance(chat_id, int) and chat_id > 0:
        cache = acc.get("peer_cache")
        if isinstance(cache, dict):
            entry = cache.get(str(chat_id))
            if isinstance(entry, dict):
                try:
                    access_hash = int(entry.get("access_hash") or 0)
                except Exception:
                    access_hash = 0
                if access_hash:
                    return InputPeerUser(chat_id, access_hash)
    return chat_id


def listener_enabled() -> bool:
    return get_listener_cfg()["enabled"]

def _send_cfg() -> Dict[str, Any]:
    cfg = load_config()
    return cfg.get("send", {}) or {}

def _send_lock_for_account(account_id: str) -> threading.Lock:
    with _send_locks_lock:
        if account_id not in _send_locks:
            _send_locks[account_id] = threading.Lock()
        return _send_locks[account_id]

_ensure_dirs()
cleanup_media_dir()
_media_gc_thread = threading.Thread(target=_media_gc_worker, daemon=True)
_media_gc_thread.start()
cleanup_media_store()
_media_store_gc_thread = threading.Thread(target=_media_store_gc_worker, daemon=True)
_media_store_gc_thread.start()

try:
    from flask_cors import CORS
    _cfg = load_config()
    _origins = _cfg.get("server", {}).get("cors_origins") or []
    if _origins:
        CORS(app, supports_credentials=True, origins=_origins)
except Exception:
    pass


# =========================================================
# Auth helpers
# =========================================================
def make_session_value(cfg: Dict[str, Any]) -> str:
    secret = cfg["admin"]["session_secret"]
    rand = secrets.token_urlsafe(24)
    ts = now_epoch()
    msg = f"{rand}.{ts}"
    sig = hmac.new(secret.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256).hexdigest()
    return f"v1.{rand}.{ts}.{sig}"


def is_logged_in(cfg: Dict[str, Any], req) -> bool:
    cookie = req.cookies.get(COOKIE_NAME, "")
    if not cookie:
        return False
    parts = cookie.split(".")
    if len(parts) != 4:
        return False
    ver, rand, ts_str, sig = parts
    if ver != "v1":
        return False
    try:
        ts = int(ts_str)
    except Exception:
        return False
    if now_epoch() - ts > COOKIE_MAX_AGE:
        return False
    secret = cfg["admin"]["session_secret"]
    msg = f"{rand}.{ts}"
    expected = hmac.new(secret.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, sig)


def get_bearer(req) -> Optional[str]:
    auth = req.headers.get("Authorization", "")
    if not auth:
        return None
    if not auth.lower().startswith("bearer "):
        return None
    return auth.split(" ", 1)[1].strip() or None


def api_access_ok(cfg: Dict[str, Any], req) -> bool:
    require_bearer = bool(cfg.get("api", {}).get("require_bearer_on_api", True))
    if not require_bearer:
        return is_logged_in(cfg, req)
    bearer = get_bearer(req)
    return bool(bearer and bearer == cfg.get("api", {}).get("bearer_token"))


def require_api_access(fn):
    def wrapper(*args, **kwargs):
        cfg = load_config()
        if not api_access_ok(cfg, request):
            return jsonify({"ok": False, "error": "unauthorized"}), 401
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


def require_admin_session(fn):
    def wrapper(*args, **kwargs):
        cfg = load_config()
        if not is_logged_in(cfg, request):
            return jsonify({"ok": False, "error": "unauthorized"}), 401
        return fn(*args, **kwargs)
    wrapper.__name__ = fn.__name__
    return wrapper


# =========================================================
# Fingerprints
# =========================================================
def _fingerprints_cfg_from(cfg: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if isinstance(cfg, dict):
        if "profiles" in cfg:
            profiles = cfg.get("profiles") or []
            if profiles:
                return cfg
        fps = cfg.get("fingerprints")
        if isinstance(fps, dict):
            profiles = fps.get("profiles") or []
            if profiles:
                return fps
    return get_fingerprints_cfg()


def get_fingerprints_cfg() -> Dict[str, Any]:
    data, status = read_json_with_status(FINGERPRINTS_PATH, {})
    if status == "ok" and isinstance(data, dict):
        return {
            "default_id": data.get("default_id"),
            "profiles": data.get("profiles") or [],
        }

    cfg = load_config()
    fps = cfg.get("fingerprints", {}) if isinstance(cfg.get("fingerprints"), dict) else {}
    profiles = fps.get("profiles") or []
    default_id = fps.get("default_id")
    if profiles:
        try:
            write_json_atomic(FINGERPRINTS_PATH, {"default_id": default_id, "profiles": profiles})
        except Exception:
            pass
    return {"default_id": default_id, "profiles": profiles}


def validate_fingerprint(cfg: Dict[str, Any], fid: str) -> bool:
    fps = _fingerprints_cfg_from(cfg).get("profiles", []) or []
    return any(p.get("id") == fid for p in fps)


def default_fingerprint_id(cfg: Dict[str, Any]) -> Optional[str]:
    fps_cfg = _fingerprints_cfg_from(cfg)
    did = fps_cfg.get("default_id")
    if did and validate_fingerprint(fps_cfg, did):
        return did
    fps = fps_cfg.get("profiles", []) or []
    if fps and fps[0].get("id"):
        return fps[0]["id"]
    return None


def get_fingerprint_profile(cfg: Dict[str, Any], fid: Optional[str]) -> Optional[Dict[str, Any]]:
    if not fid:
        return None
    fps = _fingerprints_cfg_from(cfg).get("profiles", []) or []
    for p in fps:
        if p.get("id") == fid:
            return p
    return None


def build_telegram_client(session_path: str, api_id: int, api_hash: str, fp: Optional[Dict[str, Any]] = None) -> TelegramClient:
    kwargs: Dict[str, Any] = {}
    if fp:
        for key in ("device_model", "system_version", "app_version", "lang_code", "system_lang_code", "lang_pack"):
            val = fp.get(key)
            if val:
                kwargs[key] = str(val)
        if "lang_code" in kwargs and "system_lang_code" not in kwargs:
            kwargs["system_lang_code"] = kwargs["lang_code"]
    return TelegramClient(session_path, api_id, api_hash, **kwargs)


def _set_account_last_error(account_id: str, err: Optional[str]) -> None:
    try:
        acc = read_account(account_id)
        if not acc:
            return
        acc["last_error"] = err
        acc["updated_at"] = now_epoch()
        write_account(account_id, acc)
    except Exception:
        pass


def _set_account_rate_limited(account_id: str, seconds: int) -> None:
    try:
        acc = read_account(account_id)
        if not acc:
            return
        acc["rate_limited"] = True
        acc["retry_after"] = int(seconds)
        acc["rate_limit_until"] = now_epoch() + int(seconds)
        acc["last_error"] = "FLOOD_WAIT"
        acc["updated_at"] = now_epoch()
        write_account(account_id, acc)
    except Exception:
        pass


def _get_current_webhook_url(account_id: str) -> str:
    acc = read_account(account_id) or {}
    url = str(acc.get("webhook_url") or "").strip()
    if not url:
        cfg = load_config()
        url = str(cfg.get("webhook", {}).get("default_url") or "").strip()
    return url


def _debug_webhook(msg: str) -> None:
    flag = str(os.getenv("TGS_DEBUG_WEBHOOK", "")).lower()
    if flag in ("1", "true", "yes"):
        _log_debug(msg)


# =========================================================
# Accounts: 1 JSON por conta em sessions/<id>.json
# =========================================================
def safe_account_id(account_id: str) -> bool:
    return bool(ID_RE.match(account_id or ""))


def account_json_path(account_id: str) -> str:
    return os.path.join(SESSIONS_DIR, f"{account_id}.json")


def account_session_rel(account_id: str) -> str:
    return os.path.join("sessions", f"{account_id}.session")


def account_session_abs(account_id: str) -> str:
    return os.path.join(SESSIONS_DIR, f"{account_id}.session")


def _resolve_session_path(account_id: str, acc: Optional[Dict[str, Any]] = None) -> str:
    desired = account_session_abs(account_id)
    if acc is None:
        acc = read_account(account_id) or {}

    old_rel = str(acc.get("session_path") or "").strip()
    if old_rel:
        old_abs = old_rel if os.path.isabs(old_rel) else os.path.join(BASE_DIR, old_rel)
        if os.path.abspath(old_abs) != os.path.abspath(desired):
            if os.path.exists(old_abs) and not os.path.exists(desired):
                try:
                    os.replace(old_abs, desired)
                    acc["session_path"] = account_session_rel(account_id)
                    acc["updated_at"] = now_epoch()
                    write_account(account_id, acc)
                except Exception:
                    pass
    return desired


def read_account(account_id: str) -> Optional[Dict[str, Any]]:
    if not safe_account_id(account_id):
        return None
    path = account_json_path(account_id)
    if not os.path.exists(path):
        return None
    data = read_json(path, None)
    if not isinstance(data, dict):
        return None
    return data


def write_account(account_id: str, data: Dict[str, Any]) -> None:
    write_json_atomic(account_json_path(account_id), data)


def _update_peer_cache(account_id: str, sender: Any) -> None:
    try:
        user_id = int(getattr(sender, "id", 0) or 0)
        access_hash = int(getattr(sender, "access_hash", 0) or 0)
    except Exception:
        return
    if not user_id or not access_hash:
        return

    acc = read_account(account_id)
    if not acc:
        return

    cache = acc.get("peer_cache")
    if not isinstance(cache, dict):
        cache = {}

    cache[str(user_id)] = {
        "id": user_id,
        "access_hash": access_hash,
        "username": str(getattr(sender, "username", "") or ""),
        "first_name": str(getattr(sender, "first_name", "") or ""),
        "last_name": str(getattr(sender, "last_name", "") or ""),
        "ts": now_epoch(),
    }

    if len(cache) > 5000:
        ordered = sorted(cache.items(), key=lambda kv: int(kv[1].get("ts") or 0))
        for k, _ in ordered[: len(cache) - 5000]:
            cache.pop(k, None)

    acc["peer_cache"] = cache
    acc["updated_at"] = now_epoch()
    write_account(account_id, acc)


def delete_account_files(account_id: str) -> Dict[str, bool]:
    out = {"deleted_json": False, "deleted_session": False, "deleted_aux": False}
    acc = read_account(account_id) or {}
    jpath = account_json_path(account_id)
    spath = account_session_abs(account_id)
    extra_paths: List[str] = []
    old_rel = str(acc.get("session_path") or "").strip()
    if old_rel:
        old_abs = old_rel if os.path.isabs(old_rel) else os.path.join(BASE_DIR, old_rel)
        if os.path.abspath(old_abs) != os.path.abspath(spath):
            extra_paths.append(old_abs)

    if os.path.exists(jpath) and os.path.isfile(jpath):
        try:
            os.remove(jpath)
            out["deleted_json"] = True
        except Exception:
            out["deleted_json"] = False

    session_paths = [spath] + extra_paths
    for base in session_paths:
        if os.path.exists(base) and os.path.isfile(base):
            try:
                os.remove(base)
                out["deleted_session"] = True
            except Exception:
                out["deleted_session"] = False
        for suffix in ("-journal", "-wal", "-shm"):
            aux = f"{base}{suffix}"
            if os.path.exists(aux) and os.path.isfile(aux):
                try:
                    os.remove(aux)
                    out["deleted_aux"] = True
                except Exception:
                    out["deleted_aux"] = False

    return out


def list_accounts() -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    try:
        for name in os.listdir(SESSIONS_DIR):
            if not name.endswith(".json"):
                continue
            account_id = name[:-5]
            if not safe_account_id(account_id):
                continue
            data = read_json(os.path.join(SESSIONS_DIR, name), None)
            if isinstance(data, dict) and data.get("id"):
                clean = dict(data)
                clean.pop("api_id", None)
                clean.pop("api_hash", None)
                items.append(clean)
    except Exception:
        pass
    items.sort(key=lambda x: int(x.get("created_at") or 0))
    return items


# =========================================================
# Webhook queue + jobs
# =========================================================
webhook_queue: "queue.Queue[str]" = queue.Queue()
jobs: Dict[str, Dict[str, Any]] = {}
JOB_TTL_SECONDS = 60 * 60
JOBS_MAX = 2000
LISTENER_QUEUE_MAX = 5000
listener_queue: "queue.Queue[Dict[str, Any]]" = queue.Queue(maxsize=LISTENER_QUEUE_MAX)
_queue_stats_lock = threading.Lock()
_queue_stats = {"last_sent_at": None, "last_error": None, "dead_letter_count": 0}


def _webhook_queue_key() -> str:
    return _redis_key("webhook_queue")


def _webhook_jobs_index_key() -> str:
    return _redis_key("webhook_jobs")


def _webhook_job_key(job_id: str) -> str:
    return _redis_key("webhook_job", job_id)


def _webhook_queue_put(job_id: str) -> None:
    r = _redis_client() if _redis_enabled() else None
    if r:
        r.rpush(_webhook_queue_key(), job_id)
        return
    webhook_queue.put(job_id)


def _webhook_queue_get() -> Optional[str]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        try:
            item = r.brpop(_webhook_queue_key(), timeout=5)
            return item[1] if item else None
        except Exception:
            return None
    return webhook_queue.get()


def _webhook_queue_qsize() -> int:
    r = _redis_client() if _redis_enabled() else None
    if r:
        return int(r.llen(_webhook_queue_key()))
    return webhook_queue.qsize()


def _webhook_queue_task_done() -> None:
    r = _redis_client() if _redis_enabled() else None
    if r:
        return
    webhook_queue.task_done()


def _listener_queue_key() -> str:
    return _redis_key("listener_queue")


def _listener_queue_put(job: Dict[str, Any]) -> bool:
    r = _redis_client() if _redis_enabled() else None
    if r:
        try:
            if r.llen(_listener_queue_key()) >= LISTENER_QUEUE_MAX:
                _queue_stats_inc_dead_letter()
                _log_debug("Listener queue full - dropping job (redis)")
                return False
            r.rpush(_listener_queue_key(), json.dumps(job, ensure_ascii=False))
            r.incr(_redis_key("listener_count"))
            _log_debug("Listener queued via redis")
            return True
        except Exception:
            return False
    try:
        listener_queue.put_nowait(job)
        return True
    except queue.Full:
        _queue_stats_inc_dead_letter()
        _log_debug("Listener queue full - dropping job")
        return False


def _listener_queue_get() -> Optional[Dict[str, Any]]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        try:
            item = r.brpop(_listener_queue_key(), timeout=5)
            if not item:
                return None
            raw = item[1]
            if not raw:
                return None
            return json.loads(raw)
        except Exception:
            return None
    return listener_queue.get()


def _listener_queue_qsize() -> int:
    r = _redis_client() if _redis_enabled() else None
    if r:
        try:
            return int(r.llen(_listener_queue_key()))
        except Exception:
            return 0
    return listener_queue.qsize()


def _listener_queue_task_done() -> None:
    r = _redis_client() if _redis_enabled() else None
    if r:
        return
    listener_queue.task_done()


def _jobs_cleanup() -> None:
    now = now_epoch()
    r = _redis_client() if _redis_enabled() else None
    if r:
        idx_key = _webhook_jobs_index_key()
        expired_ids = r.zrangebyscore(idx_key, 0, now - JOB_TTL_SECONDS)
        for job_id in expired_ids:
            r.delete(_webhook_job_key(job_id))
            r.zrem(idx_key, job_id)

        total = int(r.zcard(idx_key))
        if total > JOBS_MAX:
            remove_count = total - JOBS_MAX
            old_ids = r.zrange(idx_key, 0, remove_count - 1)
            if old_ids:
                for job_id in old_ids:
                    r.delete(_webhook_job_key(job_id))
                r.zrem(idx_key, *old_ids)
        return

    with _job_lock:
        expired = []
        for job_id, job in jobs.items():
            try:
                created_at = int(job.get("created_at") or 0)
            except Exception:
                created_at = 0
            if created_at and (now - created_at) > JOB_TTL_SECONDS:
                expired.append(job_id)
        for job_id in expired:
            jobs.pop(job_id, None)

        if len(jobs) > JOBS_MAX:
            ordered = sorted(
                jobs.items(),
                key=lambda kv: int(kv[1].get("created_at") or 0),
            )
            for job_id, _ in ordered[:-JOBS_MAX]:
                jobs.pop(job_id, None)


def _jobs_gc_worker():
    while True:
        time.sleep(JOB_TTL_SECONDS)
        _jobs_cleanup()


def _queue_stats_set(**fields) -> None:
    with _queue_stats_lock:
        _queue_stats.update(fields)


def _queue_stats_inc_dead_letter() -> None:
    with _queue_stats_lock:
        _queue_stats["dead_letter_count"] = int(_queue_stats.get("dead_letter_count") or 0) + 1


def _queue_stats_snapshot() -> Dict[str, Any]:
    with _queue_stats_lock:
        snap = dict(_queue_stats)
    r = _redis_client() if _redis_enabled() else None
    if r:
        try:
            snap["listener_redis_count"] = int(r.get(_redis_key("listener_count")) or 0)
        except Exception:
            snap["listener_redis_count"] = 0
    return snap


def _webhook_status_payload() -> Dict[str, Any]:
    snap = _queue_stats_snapshot()
    return {
        "webhook_last_sent_at": snap.get("last_sent_at"),
        "webhook_last_error": snap.get("last_error"),
        "webhook_dead_letter_count": snap.get("dead_letter_count"),
        "listener_queue_size": _listener_queue_qsize(),
    }


def set_job(job_id: str, **fields):
    r = _redis_client() if _redis_enabled() else None
    if r:
        payload = fields.pop("payload", None)
        update_fields = dict(fields)
        if payload is not None:
            update_fields["payload_json"] = json.dumps(payload, ensure_ascii=False)
        if update_fields:
            r.hset(_webhook_job_key(job_id), mapping=update_fields)
        return

    with _job_lock:
        job = jobs.get(job_id)
        if not job:
            return
        job.update(fields)


def get_job(job_id: str) -> Optional[Dict[str, Any]]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        data = r.hgetall(_webhook_job_key(job_id))
        if not data:
            return None
        payload_raw = data.get("payload_json")
        try:
            payload = json.loads(payload_raw) if payload_raw else None
        except Exception:
            payload = payload_raw
        return {
            "job_id": data.get("job_id"),
            "created_at": int(data.get("created_at") or 0),
            "status": data.get("status"),
            "tries": int(data.get("tries") or 0),
            "last_error": data.get("last_error"),
            "url": data.get("url"),
            "payload": payload,
        }

    with _job_lock:
        return jobs.get(job_id)


def _store_webhook_job(job: Dict[str, Any]) -> None:
    job_id = str(job.get("job_id") or "").strip()
    if not job_id:
        return
    r = _redis_client() if _redis_enabled() else None
    if r:
        created_at = int(job.get("created_at") or now_epoch())
        payload = job.get("payload")
        r.hset(_webhook_job_key(job_id), mapping={
            "job_id": job_id,
            "created_at": created_at,
            "status": job.get("status") or "",
            "tries": int(job.get("tries") or 0),
            "last_error": job.get("last_error") or "",
            "url": job.get("url") or "",
            "payload_json": json.dumps(payload, ensure_ascii=False) if payload is not None else "",
        })
        r.zadd(_webhook_jobs_index_key(), {job_id: created_at})
        return
    with _job_lock:
        jobs[job_id] = job


def enqueue_webhook(payload: Dict[str, Any], url: str = "") -> str:
    job_id = uuid.uuid4().hex
    job = {
        "job_id": job_id,
        "created_at": now_epoch(),
        "status": "queued",
        "tries": 0,
        "last_error": None,
        "url": url,
        "payload": payload,
    }
    r = _redis_client() if _redis_enabled() else None
    if r:
        r.hset(_webhook_job_key(job_id), mapping={
            "job_id": job_id,
            "created_at": job["created_at"],
            "status": "queued",
            "tries": 0,
            "last_error": "",
            "url": url,
            "payload_json": json.dumps(payload, ensure_ascii=False),
        })
        r.zadd(_webhook_jobs_index_key(), {job_id: job["created_at"]})
        _webhook_queue_put(job_id)
    else:
        _store_webhook_job(job)
        _webhook_queue_put(job_id)
    _log_debug(f"Job enqueued job_id={job_id} account_id={payload.get('account_id') if isinstance(payload, dict) else ''}")
    return job_id


def enqueue_listener_job(job: Dict[str, Any]) -> bool:
    return _listener_queue_put(job)


def _post_webhook_with_retry(url: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    backoffs = [1, 2, 4]
    last_err = None
    last_status = None
    for attempt in range(3):
        try:
            r = requests.post(url, json=payload, timeout=8)
            last_status = r.status_code
            if 200 <= r.status_code < 300:
                return {"ok": True, "status": r.status_code}
            if r.status_code == 429 or r.status_code >= 500:
                last_err = f"http_{r.status_code}"
                if attempt < 2:
                    time.sleep(backoffs[attempt])
                    continue
            return {"ok": False, "status": r.status_code, "error": f"http_{r.status_code}"}
        except requests.exceptions.Timeout:
            last_err = "timeout"
            if attempt < 2:
                time.sleep(backoffs[attempt])
                continue
            return {"ok": False, "status": None, "error": "timeout"}
        except requests.exceptions.RequestException:
            last_err = "conn_error"
            if attempt < 2:
                time.sleep(backoffs[attempt])
                continue
            return {"ok": False, "status": None, "error": "conn_error"}
    return {"ok": False, "status": last_status, "error": last_err or "send_failed"}


def listener_worker():
    while True:
        job = _listener_queue_get()
        if not job:
            continue
        try:
            account_id = job.get("account_id")
            url = (job.get("webhook_url") or "").strip()
            payload = dict(job.get("payload") or {})
            msg = job.get("message")

            if not url:
                url = _get_current_webhook_url(str(account_id))
            if not url:
                _queue_stats_inc_dead_letter()
                _queue_stats_set(last_error="missing_webhook_url")
                continue

            if payload.get("has_media"):
                kind = job.get("kind") or "private"
                cfg = get_listener_cfg()
                if not should_download_media(kind, cfg):
                    payload["media_error"] = "download_skipped"
                    result = _post_webhook_with_retry(url, payload)
                    _queue_stats_set(last_sent_at=now_epoch(), last_error=result.get("error"))
                    if result.get("ok"):
                        _queue_stats_set(last_error=None)
                    else:
                        _queue_stats_inc_dead_letter()
                    _log_debug(f"Webhook POST status account_id={account_id} code={result.get('status')}")
                    continue

                client = None
                with _listener_lock:
                    info = _listeners.get(str(account_id)) or {}
                    client = info.get("client")
                if not client:
                    payload["media_error"] = "client_missing"
                else:
                    if not msg:
                        msg_id = job.get("msg_id") or payload.get("msg_id")
                        chat_id = job.get("chat_id") or payload.get("chat_id")
                        if msg_id and chat_id:
                            try:
                                fetched = _run_coro(client.get_messages(chat_id, ids=int(msg_id)), timeout=60)
                                if isinstance(fetched, list):
                                    msg = fetched[0] if fetched else None
                                else:
                                    msg = fetched
                            except Exception:
                                msg = None
                        if not msg:
                            payload["media_error"] = "message_missing"
                            result = _post_webhook_with_retry(url, payload)
                            _queue_stats_set(last_sent_at=now_epoch(), last_error=result.get("error"))
                            if result.get("ok"):
                                _queue_stats_set(last_error=None)
                            else:
                                _queue_stats_inc_dead_letter()
                            _log_debug(f"Webhook POST status account_id={account_id} code={result.get('status')}")
                            continue

                    media_kind = _media_kind(msg)
                    if media_kind == "pdf":
                        media = _run_coro(_save_pdf_and_preview(client, msg), timeout=120)
                        media_id = media.get("pdf")
                        if media_id:
                            payload["media_id"] = media_id
                            payload["media_id_pdf"] = media.get("pdf")
                            payload["media_id_img"] = media.get("img")
                            payload.update(_media_metadata(msg))
                        else:
                            payload["media_error"] = "download_failed"
                    else:
                        media = _run_coro(_save_media_temp(client, msg), timeout=120)
                        if media and media.get("media_id"):
                            payload["media_id"] = media.get("media_id")
                            payload.update(_media_metadata(msg))
                        else:
                            payload["media_error"] = "download_failed"

            result = _post_webhook_with_retry(url, payload)
            _queue_stats_set(last_sent_at=now_epoch(), last_error=result.get("error"))
            if result.get("ok"):
                _queue_stats_set(last_error=None)
            else:
                _queue_stats_inc_dead_letter()
            _log_debug(f"Webhook POST status account_id={account_id} code={result.get('status')}")
        except Exception as e:
            _queue_stats_inc_dead_letter()
            _queue_stats_set(last_error=str(e))
            _log_debug(f"Listener worker error account_id={job.get('account_id')} error={str(e)}")
        finally:
            _listener_queue_task_done()

def webhook_worker():
    while True:
        job_id = _webhook_queue_get()
        if not job_id:
            continue
        queue_delay_threshold = 0
        queue_delay_seconds = 0.0
        try:
            cfg = load_config()
            job = get_job(job_id)
            if not job:
                continue

            url = (job.get("url") or "").strip()
            payload = job.get("payload") or {}
            if not isinstance(payload, dict):
                payload = {"payload": payload}

            if not url:
                url = (cfg.get("webhook", {}).get("default_url") or "").strip()

            wh = cfg.get("webhook", {}) or {}
            enabled = bool(wh.get("enabled", False))
            timeout_sec = int(wh.get("timeout_sec") or wh.get("timeout_seconds") or 10)
            max_retries = int(wh.get("max_retries") or wh.get("retries") or 3)
            retry_delay = int(wh.get("retry_delay_sec") or wh.get("retry_delay_seconds") or 2)
            queue_delay_threshold = int(wh.get("queue_delay_threshold") or 0)
            try:
                queue_delay_seconds = float(wh.get("queue_delay_seconds") or 0)
            except Exception:
                queue_delay_seconds = 0.0

            if not enabled or not url:
                set_job(job_id, status="failed", last_error="webhook_disabled_or_missing_url")
                _log_debug(f"Webhook disabled or missing url job_id={job_id}")
                continue

            tries = int(job.get("tries") or 0)
            set_job(job_id, status="sending", last_error=None)

            last_err = None
            success = False

            while tries < max_retries and not success:
                tries += 1
                try:
                    _log_debug(f"Webhook POST start job_id={job_id} url={url}")
                    r = requests.post(url, json=payload, timeout=timeout_sec)
                    _log_debug(f"Webhook POST status job_id={job_id} code={r.status_code}")
                    if 200 <= r.status_code < 300:
                        success = True
                        break
                    last_err = f"HTTP_{r.status_code}"
                except Exception as e:
                    last_err = str(e)
                    _log_debug(f"Webhook POST error job_id={job_id} error={last_err}")

                if tries < max_retries:
                    set_job(job_id, status="retrying", tries=tries, last_error=last_err)
                    time.sleep(retry_delay)

            if success:
                set_job(job_id, status="sent", tries=tries, last_error=None)
                if isinstance(payload, dict):
                    acc_id = payload.get("account_id")
                    if acc_id:
                        _set_account_last_error(str(acc_id), None)
            else:
                set_job(job_id, status="failed", tries=tries, last_error=last_err)
                if isinstance(payload, dict):
                    acc_id = payload.get("account_id")
                    if acc_id:
                        _set_account_last_error(str(acc_id), str(last_err))
        except Exception as e:
            _log_debug(f"Webhook worker error job_id={job_id} error={str(e)}")
            job = get_job(job_id)
            if job:
                set_job(job_id, status="failed", last_error=str(e))
                payload = job.get("payload")
                if isinstance(payload, dict):
                    acc_id = payload.get("account_id")
                    if acc_id:
                        _set_account_last_error(str(acc_id), str(e))
        finally:
            try:
                _webhook_queue_task_done()
            except Exception:
                pass
            try:
                if queue_delay_threshold > 0 and queue_delay_seconds > 0:
                    if _webhook_queue_qsize() >= queue_delay_threshold:
                        time.sleep(queue_delay_seconds)
            except Exception:
                pass

_workers_lock = threading.Lock()
_webhook_threads: List[threading.Thread] = []
_listener_threads: List[threading.Thread] = []


def _start_webhook_worker() -> threading.Thread:
    t = threading.Thread(target=webhook_worker, daemon=True)
    t.start()
    return t


def _start_listener_worker() -> threading.Thread:
    t = threading.Thread(target=listener_worker, daemon=True)
    t.start()
    return t


def _workers_watchdog() -> None:
    while True:
        time.sleep(5)
        with _workers_lock:
            _webhook_threads[:] = [t for t in _webhook_threads if t.is_alive()]
            _listener_threads[:] = [t for t in _listener_threads if t.is_alive()]
            while len(_webhook_threads) < WEBHOOK_WORKERS:
                _log_debug("Webhook worker down - restarting")
                _webhook_threads.append(_start_webhook_worker())
            while len(_listener_threads) < LISTENER_WORKERS:
                _log_debug("Listener worker down - restarting")
                _listener_threads.append(_start_listener_worker())


with _workers_lock:
    for _ in range(WEBHOOK_WORKERS):
        _webhook_threads.append(_start_webhook_worker())
    for _ in range(LISTENER_WORKERS):
        _listener_threads.append(_start_listener_worker())
threading.Thread(target=_workers_watchdog, daemon=True).start()
threading.Thread(target=_jobs_gc_worker, daemon=True).start()


# =========================================================
# Telethon async runner (um loop em thread)
# =========================================================
tg_loop = asyncio.new_event_loop()

def _tg_loop_runner():
    asyncio.set_event_loop(tg_loop)
    tg_loop.run_forever()

threading.Thread(target=_tg_loop_runner, daemon=True).start()

# Estado temporÃ¡rio de login por conta:
# account_id -> { client, phone, api_id, api_hash, step, phone_code_hash }
tg_login_state: Dict[str, Dict[str, Any]] = {}
tg_state_lock = threading.Lock()


def _run_coro(coro, timeout=40):
    fut = asyncio.run_coroutine_threadsafe(coro, tg_loop)
    return fut.result(timeout=timeout)


def _listener_running(account_id: str) -> bool:
    with _listener_lock:
        return account_id in _listeners or account_id in _listener_starting


def _listener_stats_get(account_id: str) -> Dict[str, int]:
    with _listener_stats_lock:
        stats = _listener_stats.get(account_id)
        if not stats:
            stats = {"incoming_forwarded": 0, "outgoing_ignored": 0}
            _listener_stats[account_id] = stats
        return dict(stats)


def _listener_stats_inc(account_id: str, key: str) -> None:
    with _listener_stats_lock:
        stats = _listener_stats.setdefault(account_id, {"incoming_forwarded": 0, "outgoing_ignored": 0})
        stats[key] = int(stats.get(key, 0)) + 1


def _listener_health_get(account_id: str) -> Dict[str, Any]:
    with _listener_health_lock:
        return dict(_listener_health.get(account_id) or {})


def _listener_health_set(account_id: str, **fields) -> None:
    with _listener_health_lock:
        item = _listener_health.setdefault(account_id, {})
        item.update(fields)


def _listener_record_start(account_id: str) -> None:
    _listener_health_set(
        account_id,
        last_start_at=now_epoch(),
        last_error=None,
        last_stop_at=None,
        restart_attempts=0,
        next_restart_at=0,
        stop_requested=False,
    )


def _listener_record_stop(account_id: str, err: Optional[str]) -> None:
    now = now_epoch()
    with _listener_health_lock:
        item = _listener_health.setdefault(account_id, {})
        item["last_stop_at"] = now
        if err:
            item["last_error"] = err
        elif not item.get("stop_requested"):
            item["last_error"] = "listener_stopped"
        if item.get("stop_requested"):
            item["next_restart_at"] = 0
            return
        attempts = int(item.get("restart_attempts") or 0) + 1
        item["restart_attempts"] = attempts
        idx = min(attempts - 1, len(LISTENER_RESTART_BACKOFF) - 1)
        item["next_restart_at"] = now + LISTENER_RESTART_BACKOFF[idx]


def _listener_should_restart(account_id: str) -> bool:
    info = _listener_health_get(account_id)
    if info.get("stop_requested"):
        return False
    next_at = int(info.get("next_restart_at") or 0)
    return now_epoch() >= next_at


def _listener_status_payload(account_id: str) -> Dict[str, Any]:
    info = _listener_health_get(account_id)
    return {
        "listener_running": _listener_running(account_id),
        "listener_last_error": info.get("last_error"),
        "listener_last_start_at": info.get("last_start_at"),
        "listener_last_stop_at": info.get("last_stop_at"),
        "listener_restart_attempts": int(info.get("restart_attempts") or 0),
        "listener_next_restart_at": info.get("next_restart_at"),
        **_listener_stats_get(account_id),
    }

def _listener_register(account_id: str, client: TelegramClient) -> None:
    with _listener_lock:
        _listeners[account_id] = {"client": client, "started_at": now_epoch()}
        _listener_starting.discard(account_id)
    _listener_stats_get(account_id)
    _listener_record_start(account_id)


def _listener_unregister(account_id: str) -> None:
    with _listener_lock:
        _listeners.pop(account_id, None)
        _listener_starting.discard(account_id)


def _listener_mark_starting(account_id: str) -> None:
    with _listener_lock:
        _listener_starting.add(account_id)


def _listener_clear_starting(account_id: str) -> None:
    with _listener_lock:
        _listener_starting.discard(account_id)


def _safe_ext(ext: str) -> str:
    ext = (ext or "").strip().lower()
    if not ext:
        return ""
    if not ext.startswith("."):
        ext = "." + ext
    ext = re.sub(r"[^a-z0-9\\.]", "", ext)
    if len(ext) > 10:
        return ""
    return ext


def _guess_ext_from_content_type(content_type: str) -> str:
    if not content_type:
        return ""
    ct = content_type.split(";", 1)[0].strip().lower()
    if ct in CONTENT_TYPE_EXT:
        return CONTENT_TYPE_EXT[ct]
    guessed = mimetypes.guess_extension(ct)
    return guessed or ""


def _guess_ext_from_url(url: str) -> str:
    try:
        path = urlparse(url).path or ""
        return os.path.splitext(path)[1] or ""
    except Exception:
        return ""

def _is_gif_file(path: str) -> bool:
    ext = os.path.splitext(path or "")[1].lower()
    if ext == ".gif":
        return True
    return (mimetypes.guess_type(path)[0] or "").lower() == "image/gif"


def _download_url_to_media(url: str) -> Dict[str, Any]:
    if not url or not re.match(r"^https?://", url, re.IGNORECASE):
        return {"ok": False, "error": "download_failed", "detail": "invalid_url"}

    if not _media_store_enabled():
        return {"ok": False, "error": "download_failed", "detail": "store_disabled"}

    url_hash = hashlib.sha1(url.encode("utf-8")).hexdigest()
    store_dir = _media_store_dir_abs()
    cached_path = ""
    try:
        for entry in os.scandir(store_dir):
            if entry.is_file() and entry.name.startswith(f"url_{url_hash}"):
                cached_path = entry.path
                break
    except Exception:
        cached_path = ""

    if cached_path:
        media_id = f"store_{url_hash}"
        _media_cache_set(media_id, {
            "media_id": media_id,
            "path": cached_path,
            "mime": mimetypes.guess_type(cached_path)[0] or "application/octet-stream",
            "created_at": now_epoch(),
        })
        return {
            "ok": True,
            "path": cached_path,
            "cached": True,
            "media_id": media_id,
            "http_status_download": None,
            "bytes_downloaded": None,
        }

    attempts = 3
    backoffs = [1, 2, 4]
    last_status = None
    last_detail = "download_failed"
    for attempt in range(attempts):
        try:
            with requests.get(url, stream=True, timeout=(8, 60)) as resp:
                last_status = resp.status_code
                if resp.status_code == 429 or resp.status_code >= 500:
                    last_detail = f"http_{resp.status_code}"
                    if attempt < attempts - 1:
                        time.sleep(backoffs[attempt])
                        continue
                    return {
                        "ok": False,
                        "error": "download_failed",
                        "detail": last_detail,
                        "http_status_download": resp.status_code,
                    }
                if resp.status_code >= 400:
                    return {
                        "ok": False,
                        "error": "download_failed",
                        "detail": f"http_{resp.status_code}",
                        "http_status_download": resp.status_code,
                    }

                content_length = resp.headers.get("content-length")
                if content_length:
                    try:
                        if int(content_length) > MAX_REMOTE_FILE_BYTES:
                            return {
                                "ok": False,
                                "error": "file_too_large",
                                "detail": "content_length",
                                "http_status_download": resp.status_code,
                            }
                    except Exception:
                        pass

                ext = _guess_ext_from_content_type(resp.headers.get("content-type", ""))
                if not ext:
                    ext = _guess_ext_from_url(url)
                ext = _safe_ext(ext) or ".bin"

                media_id = f"store_{url_hash}"
                path = os.path.join(store_dir, f"url_{url_hash}{ext}")
                total = 0
                try:
                    with open(path, "wb") as f:
                        for chunk in resp.iter_content(chunk_size=1024 * 128):
                            if not chunk:
                                continue
                            total += len(chunk)
                            if total > MAX_REMOTE_FILE_BYTES:
                                f.close()
                                try:
                                    os.remove(path)
                                except Exception:
                                    pass
                                return {
                                    "ok": False,
                                    "error": "file_too_large",
                                    "detail": "size_limit",
                                    "http_status_download": resp.status_code,
                                }
                            f.write(chunk)
                except Exception:
                    try:
                        if os.path.exists(path):
                            os.remove(path)
                    except Exception:
                        pass
                    return {"ok": False, "error": "download_failed", "detail": "write_failed"}

                mime = resp.headers.get("content-type")
                if not mime:
                    mime = mimetypes.guess_type(path)[0] or "application/octet-stream"
                _media_cache_set(media_id, {"media_id": media_id, "path": path, "mime": mime, "created_at": now_epoch()})
                return {
                    "ok": True,
                    "path": path,
                    "cached": False,
                    "media_id": media_id,
                    "http_status_download": resp.status_code,
                    "bytes_downloaded": total,
                }
        except requests.exceptions.Timeout:
            last_detail = "timeout"
            if attempt < attempts - 1:
                time.sleep(backoffs[attempt])
                continue
            return {"ok": False, "error": "download_failed", "detail": "timeout"}
        except requests.exceptions.RequestException:
            last_detail = "conn_error"
            if attempt < attempts - 1:
                time.sleep(backoffs[attempt])
                continue
            return {"ok": False, "error": "download_failed", "detail": "conn_error"}

    return {"ok": False, "error": "download_failed", "detail": last_detail, "http_status_download": last_status}


async def _save_media_temp(client: TelegramClient, msg) -> Optional[Dict[str, Any]]:
    media_id = uuid.uuid4().hex
    ext = ""
    if getattr(msg, "photo", None):
        ext = ".jpg"
    elif getattr(msg, "voice", False):
        ext = ".ogg"
    elif getattr(msg, "file", None) and getattr(msg.file, "ext", None):
        ext = msg.file.ext
    ext = _safe_ext(ext)
    if not ext:
        ext = ".bin"

    path = os.path.join(_media_dir_abs(), f"{media_id}{ext}")
    try:
        await client.download_media(msg, file=path)
    except Exception:
        return None

    mime = None
    if getattr(msg, "file", None) and getattr(msg.file, "mime_type", None):
        mime = msg.file.mime_type
    if not mime:
        mime = mimetypes.guess_type(path)[0] or "application/octet-stream"

    payload = {"media_id": media_id, "path": path, "mime": mime, "created_at": now_epoch()}
    _media_cache_set(media_id, payload)
    return payload


def _msg_has_media(msg) -> bool:
    return bool(
        getattr(msg, "photo", None)
        or getattr(msg, "document", None)
        or getattr(msg, "voice", None)
        or getattr(msg, "audio", None)
        or getattr(msg, "video", None)
    )


def _media_kind(msg) -> Optional[str]:
    if getattr(msg, "photo", None):
        return "photo"
    if getattr(msg, "video", None):
        return "video"
    if getattr(msg, "voice", None):
        return "voice"
    if getattr(msg, "audio", None):
        return "audio"
    if getattr(msg, "document", None):
        return "pdf" if _msg_is_pdf(msg) else "document"
    return None


def _media_metadata(msg) -> Dict[str, Any]:
    meta: Dict[str, Any] = {}
    file = getattr(msg, "file", None)
    if file:
        mime_type = getattr(file, "mime_type", None)
        file_name = getattr(file, "name", None)
        file_size = getattr(file, "size", None)
        if mime_type:
            meta["mime_type"] = mime_type
        if file_name:
            meta["file_name"] = file_name
        if file_size:
            meta["file_size"] = file_size
    return meta


def _normalize_fingerprint_label(label: Any) -> str:
    text = str(label or "")
    return text.replace("Ã¢â‚¬Â¢", "â€¢").replace("\u00e2\u0080\u00a2", "â€¢")


def _msg_is_pdf(msg) -> bool:
    try:
        if getattr(msg, "file", None) and getattr(msg.file, "mime_type", None):
            if str(msg.file.mime_type).lower() == "application/pdf":
                return True
        if getattr(msg, "file", None) and getattr(msg.file, "ext", None):
            return str(msg.file.ext).lower() == ".pdf"
    except Exception:
        return False
    return False


async def _save_pdf_and_preview(client: TelegramClient, msg) -> Dict[str, Optional[str]]:
    pdf_media_id = uuid.uuid4().hex
    pdf_path = os.path.join(_media_dir_abs(), f"{pdf_media_id}.pdf")
    try:
        await client.download_media(msg, file=pdf_path)
    except Exception:
        return {"pdf": None, "img": None}

    _media_cache_set(pdf_media_id, {
        "media_id": pdf_media_id,
        "path": pdf_path,
        "mime": "application/pdf",
        "created_at": now_epoch(),
    })

    img_media_id: Optional[str] = None
    try:
        from pdf2image import convert_from_path

        pages = convert_from_path(pdf_path, first_page=1, last_page=1)
        if pages:
            img_media_id = uuid.uuid4().hex
            img_path = os.path.join(_media_dir_abs(), f"{img_media_id}.jpg")
            pages[0].save(img_path, "JPEG")
            _media_cache_set(img_media_id, {
                "media_id": img_media_id,
                "path": img_path,
                "mime": "image/jpeg",
                "created_at": now_epoch(),
            })
    except Exception:
        img_media_id = None

    return {"pdf": pdf_media_id, "img": img_media_id}


async def _listener_task(account_id: str, api_id: int, api_hash: str, webhook_url: str):
    acc = read_account(account_id) or {}
    session_path = _resolve_session_path(account_id, acc)
    fps_cfg = get_fingerprints_cfg()
    fid = acc.get("fingerprint_id") or fps_cfg.get("default_id")
    fp = get_fingerprint_profile(fps_cfg, fid)
    client = build_telegram_client(session_path, api_id, api_hash, fp)
    last_err: Optional[str] = None
    try:
        _log_debug(f"Listener task starting account_id={account_id}")
        await asyncio.wait_for(client.connect(), timeout=20)
        _log_debug(f"Listener connected account_id={account_id}")
        _listener_clear_starting(account_id)
        authorized = await asyncio.wait_for(client.is_user_authorized(), timeout=10)
        if not authorized:
            _set_account_last_error(account_id, "unauthorized")
            _log_debug(f"Listener unauthorized account_id={account_id}")
            await _tg_disconnect_safely(client)
            return
        me = await client.get_me()
        if not me:
            _set_account_last_error(account_id, "unauthorized")
            _log_debug(f"Listener get_me empty account_id={account_id}")
            await _tg_disconnect_safely(client)
            return
        _log_debug(f"Listener started account_id={account_id}")
        me_id = getattr(me, "id", None)

        async def _on_message(event):
            try:
                msg = event.message
                if not msg:
                    return

                is_out = bool(
                    getattr(msg, "out", False)
                    or getattr(event, "out", False)
                    or (me_id and getattr(event, "sender_id", None) == me_id)
                )
                if is_out:
                    _listener_stats_inc(account_id, "outgoing_ignored")
                    _log_debug(
                        "NewMessage ignored outgoing "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"msg_id={getattr(msg, 'id', None)}"
                    )
                    return

                cfg = get_listener_cfg()
                if not cfg.get("enabled", True):
                    _log_debug(
                        "NewMessage ignored listener disabled "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"msg_id={getattr(msg, 'id', None)}"
                    )
                    return

                kind = chat_kind(event)
                if not should_forward(kind, cfg):
                    chat = getattr(event, "chat", None)
                    title = str(getattr(chat, "title", "") or "").strip()
                    _log_debug(
                        "NewMessage ignored forward disabled "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"kind={kind} title={title}"
                    )
                    return

                chat = getattr(event, "chat", None)
                title = str(getattr(chat, "title", "") or "").strip()
                _log_debug(f"NewMessage captured account_id={account_id} chat_id={getattr(event, 'chat_id', None)}")

                text = (msg.message or "").strip()
                has_media = _msg_has_media(msg)
                dt = getattr(msg, "date", None)
                date_epoch = int(dt.timestamp()) if dt else now_epoch()

                try:
                    sender = await event.get_sender()
                    _update_peer_cache(account_id, sender)
                except Exception:
                    pass

                payload = {
                    "account_id": account_id,
                    "chat_id": getattr(event, "chat_id", None),
                    "from_id": getattr(event, "sender_id", None),
                    "msg_id": getattr(msg, "id", None),
                    "date": date_epoch,
                    "text": text,
                    "has_media": bool(has_media),
                }

                url = _get_current_webhook_url(account_id)
                if url:
                    _debug_webhook(f"Using webhook URL for {account_id}: {url}")
                enqueue_listener_job({
                    "account_id": account_id,
                    "webhook_url": url,
                    "kind": kind,
                    "chat_id": payload.get("chat_id"),
                    "msg_id": payload.get("msg_id"),
                    "payload": payload,
                })
                _listener_stats_inc(account_id, "incoming_forwarded")
                _log_debug(
                    "NewMessage queued "
                    f"account_id={account_id} chat_id={payload.get('chat_id')} "
                    f"msg_id={payload.get('msg_id')} from_id={payload.get('from_id')} "
                    f"text_len={len(text)}"
                )
            except Exception as e:
                _log_debug(f"Listener error account_id={account_id} error={str(e)}")

        async def _on_album(event):
            try:
                _log_debug("Album ignored - handled by NewMessage")
                return
                msgs = list(getattr(event, "messages", []) or [])
                if not msgs:
                    return
                msg0 = msgs[0]

                is_out = bool(
                    getattr(msg0, "out", False)
                    or getattr(event, "out", False)
                    or (me_id and getattr(event, "sender_id", None) == me_id)
                )
                if is_out:
                    _listener_stats_inc(account_id, "outgoing_ignored")
                    _log_debug(
                        "Album ignored outgoing "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"msg_id={getattr(msg0, 'id', None)}"
                    )
                    return

                cfg = get_listener_cfg()
                if not cfg.get("enabled", True):
                    _log_debug(
                        "Album ignored listener disabled "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"msg_id={getattr(msg0, 'id', None)}"
                    )
                    return

                kind = chat_kind(event)
                if not should_forward(kind, cfg):
                    chat = getattr(event, "chat", None)
                    title = str(getattr(chat, "title", "") or "").strip()
                    _log_debug(
                        "Album ignored forward disabled "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"kind={kind} title={title}"
                    )
                    return

                chat = getattr(event, "chat", None)
                title = str(getattr(chat, "title", "") or "").strip()
                text = (getattr(msg0, "message", None) or "").strip()

                dt = getattr(msg0, "date", None)
                date_epoch = int(dt.timestamp()) if dt else now_epoch()

                items: List[Dict[str, Any]] = []
                skipped_any = False
                has_media_any = False

                if should_download_media(kind, cfg):
                    for m in msgs:
                        mk = _media_kind(m)
                        if mk:
                            has_media_any = True
                        item: Dict[str, Any] = {"message_id": getattr(m, "id", None), "media_kind": mk}
                        if mk == "pdf":
                            media = await _save_pdf_and_preview(client, m)
                            pdf_media_id = media.get("pdf")
                            img_media_id = media.get("img")
                            if pdf_media_id:
                                item["media_id"] = pdf_media_id
                                item["media_id_pdf"] = pdf_media_id
                                item["media_id_img"] = img_media_id
                            else:
                                item["media_skipped"] = True
                                item["media_skip_reason"] = "download_failed"
                                item.update(_media_metadata(m))
                                skipped_any = True
                        elif mk:
                            media = await _save_media_temp(client, m)
                            if media:
                                item["media_id"] = media.get("media_id")
                            else:
                                item["media_skipped"] = True
                                item["media_skip_reason"] = "download_failed"
                                item.update(_media_metadata(m))
                                skipped_any = True
                        items.append(item)
                else:
                    reason = "private_disabled"
                    if kind == "group":
                        reason = "groups_disabled"
                    elif kind == "channel":
                        reason = "channels_disabled"
                    for m in msgs:
                        mk = _media_kind(m)
                        if mk:
                            has_media_any = True
                        item = {"message_id": getattr(m, "id", None), "media_kind": mk}
                        item["media_skipped"] = True
                        item["media_skip_reason"] = reason
                        item.update(_media_metadata(m))
                        items.append(item)
                    skipped_any = True
                    _log_debug(
                        "Album media download skipped "
                        f"account_id={account_id} chat_id={getattr(event, 'chat_id', None)} "
                        f"kind={kind} reason={reason}"
                    )

                payload = {
                    "event": "album",
                    "account_id": account_id,
                    "chat_id": getattr(event, "chat_id", None),
                    "from_id": getattr(event, "sender_id", None),
                    "date": date_epoch,
                    "text": text,
                    "kind": kind,
                    "is_private": bool(getattr(event, "is_private", False)),
                    "is_group": bool(getattr(event, "is_group", False)),
                    "is_channel": bool(getattr(event, "is_channel", False)),
                    "title": title,
                    "items": items,
                    "has_media": has_media_any,
                }

                if skipped_any:
                    payload["media_skipped"] = True
                    payload["media_skip_reason"] = (
                        "download_failed" if should_download_media(kind, cfg) else items[0].get("media_skip_reason")
                    )

                url = _get_current_webhook_url(account_id)
                if url:
                    _debug_webhook(f"Using webhook URL for {account_id}: {url}")
                enqueue_webhook(payload, url)
                _listener_stats_inc(account_id, "incoming_forwarded")
                _log_debug(
                    "Album forwarded incoming "
                    f"account_id={account_id} chat_id={payload.get('chat_id')} "
                    f"count={len(items)}"
                )
            except Exception as e:
                _log_debug(f"Album listener error account_id={account_id} error={str(e)}")

        try:
            client.add_event_handler(_on_message, events.NewMessage(incoming=True))
        except Exception:
            client.add_event_handler(_on_message, events.NewMessage(outgoing=False))
        try:
            client.add_event_handler(_on_album, events.Album(incoming=True))
        except Exception:
            client.add_event_handler(_on_album, events.Album())
        _listener_register(account_id, client)
        await client.run_until_disconnected()
    except Exception as e:
        last_err = str(e)
        _set_account_last_error(account_id, last_err)
        _log_debug(f"Listener stopped account_id={account_id} error={last_err}")
    finally:
        _listener_clear_starting(account_id)
        _listener_unregister(account_id)
        _listener_record_stop(account_id, last_err)
        await _tg_disconnect_safely(client)


def start_listener_for_account(account_id: str) -> bool:
    if not listener_enabled():
        _log_debug(f"Listener disabled by config account_id={account_id}")
        return False
    if _listener_running(account_id):
        return False
    acc = read_account(account_id)
    if not acc:
        return False
    session_path = _resolve_session_path(account_id, acc)
    if not os.path.exists(session_path):
        return False
    api_id = acc.get("api_id")
    api_hash = str(acc.get("api_hash") or "").strip()
    if not api_id or not api_hash:
        return False
    try:
        api_id_int = int(api_id)
    except Exception:
        return False
    url = str(acc.get("webhook_url") or "").strip()
    if not url:
        cfg = load_config()
        url = str(cfg.get("webhook", {}).get("default_url") or "").strip()
    _listener_health_set(account_id, stop_requested=False)
    _listener_mark_starting(account_id)
    _log_debug(f"Listener start requested account_id={account_id}")
    asyncio.run_coroutine_threadsafe(
        _listener_task(account_id, api_id_int, api_hash, url),
        tg_loop
    )
    return True


def stop_listener_for_account(account_id: str) -> None:
    _listener_health_set(account_id, stop_requested=True, last_error="stopped")
    with _listener_lock:
        info = _listeners.get(account_id)
        _listener_starting.discard(account_id)
    if not info:
        return
    client = info.get("client")
    if client:
        try:
            asyncio.run_coroutine_threadsafe(client.disconnect(), tg_loop)
        except Exception:
            pass
    _listener_unregister(account_id)


def stop_all_listeners() -> None:
    with _listener_lock:
        account_ids = list(_listeners.keys())
    for acc_id in account_ids:
        stop_listener_for_account(acc_id)


def bootstrap_listeners():
    if not listener_enabled():
        _log_debug("Listener disabled by config - bootstrap skipped")
        return
    for acc in list_accounts():
        acc_id = acc.get("id")
        if acc_id:
            start_listener_for_account(acc_id)


threading.Thread(target=bootstrap_listeners, daemon=True).start()
 

def _account_ready_for_listener(acc: Dict[str, Any]) -> bool:
    acc_id = acc.get("id")
    if not acc_id:
        return False
    session_path = _resolve_session_path(acc_id, acc)
    if not os.path.exists(session_path):
        return False
    api_id = acc.get("api_id")
    api_hash = str(acc.get("api_hash") or "").strip()
    if not api_id or not api_hash:
        return False
    try:
        int(api_id)
    except Exception:
        return False
    return True


def _listener_watchdog():
    while True:
        time.sleep(15)
        if not listener_enabled():
            continue
        for acc in list_accounts():
            acc_id = acc.get("id")
            if not acc_id:
                continue
            if _listener_running(acc_id):
                continue
            with tg_state_lock:
                if acc_id in tg_login_state:
                    continue
            if not _account_ready_for_listener(acc):
                continue
            if not _listener_should_restart(acc_id):
                continue
            if start_listener_for_account(acc_id):
                _log_debug(f"Listener restart scheduled account_id={acc_id}")


threading.Thread(target=_listener_watchdog, daemon=True).start()


def _health_cache_get(account_id: str) -> Optional[Dict[str, Any]]:
    with _health_lock:
        item = _health_cache.get(account_id)
        if not item:
            return None
        if (now_epoch() - int(item.get("last_check_at") or 0)) <= HEALTH_TTL_SEC:
            return dict(item)
        return None


def _health_cache_set(account_id: str, payload: Dict[str, Any]) -> None:
    with _health_lock:
        _health_cache[account_id] = dict(payload)


def _health_cache_clear(account_id: str) -> None:
    with _health_lock:
        _health_cache.pop(account_id, None)


def _send_health_payload(account_id: str) -> Dict[str, Any]:
    cfg = _send_cfg()
    counts = db_counts_by_status(account_id)
    state = db_get_account_state(account_id)
    now = now_epoch()
    paused_until = int(state.get("paused_until") or 0)
    send_paused = bool(paused_until and now < paused_until)
    pause_remaining = max(0, paused_until - now)
    try:
        ready_threshold = int(cfg.get("ready_threshold") or cfg.get("backlog_limit") or 10)
    except Exception:
        ready_threshold = 10
    try:
        backlog_limit = int(cfg.get("backlog_limit") or ready_threshold)
    except Exception:
        backlog_limit = ready_threshold
    return {
        "send_queue_pending": int(counts.get("PENDING") or 0),
        "send_queue_sending": int(counts.get("SENDING") or 0),
        "send_queue_failed": int(counts.get("FAILED") or 0),
        "send_queue_cancelled": int(counts.get("CANCELLED") or 0),
        "send_paused": send_paused,
        "send_paused_until": paused_until,
        "send_pause_remaining_sec": pause_remaining,
        "backlog_limit": backlog_limit,
        "ready_threshold": ready_threshold,
        "send_last_ok_at": state.get("last_ok_at"),
        "send_last_error": state.get("last_error"),
        "send_last_error_at": state.get("last_error_at"),
        "send_last_send_at": state.get("last_send_at"),
    }


def _apply_ready_flags(payload: Dict[str, Any], send_info: Dict[str, Any]) -> None:
    pending = int(send_info.get("send_queue_pending") or 0)
    ready_threshold = int(send_info.get("ready_threshold") or 10)
    send_paused = bool(send_info.get("send_paused"))

    alive = bool(payload.get("alive"))
    authorized = payload.get("authorized") is True
    listener_running = bool(payload.get("listener_running"))
    ok = bool(payload.get("ok"))

    ready = ok and alive and authorized and listener_running and (not send_paused) and pending <= ready_threshold
    if not alive:
        reason = "PROCESS_DOWN"
    elif not authorized:
        reason = "UNAUTHORIZED"
    elif not listener_running:
        reason = "LISTENER_OFF"
    elif send_paused:
        reason = "FLOODWAIT"
    elif pending > ready_threshold:
        reason = "BACKLOG"
    else:
        reason = "OK"

    payload["ready_for_new_leads"] = bool(ready)
    payload["ready_reason"] = reason


def _health_check_account(account_id: str, force: bool = False) -> Dict[str, Any]:
    if not force:
        cached = _health_cache_get(account_id)
        if cached:
            return cached

    listener_info = _listener_status_payload(account_id)
    webhook_info = _webhook_status_payload()
    send_info = _send_health_payload(account_id)

    acc = read_account(account_id)
    if not acc:
        payload = {
            "ok": False,
            "account_id": account_id,
            "alive": False,
            "authorized": False,
            "last_error": "not_found",
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }
        _apply_ready_flags(payload, send_info)
        _health_cache_set(account_id, payload)
        return payload

    if _listener_running(account_id):
        payload = {
            "ok": True,
            "account_id": account_id,
            "alive": True,
            "authorized": True,
            "last_error": acc.get("last_error"),
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }
        _apply_ready_flags(payload, send_info)
        _health_cache_set(account_id, payload)
        return payload

    session_path = _resolve_session_path(account_id, acc)
    session_exists = os.path.exists(session_path)
    api_id = acc.get("api_id")
    api_hash = str(acc.get("api_hash") or "").strip()

    if not session_exists:
        payload = {
            "ok": True,
            "account_id": account_id,
            "alive": False,
            "authorized": False,
            "last_error": "no_session",
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }
        _apply_ready_flags(payload, send_info)
        _health_cache_set(account_id, payload)
        return payload

    if not api_id or not api_hash:
        payload = {
            "ok": True,
            "account_id": account_id,
            "alive": True,
            "authorized": None,
            "last_error": "missing_credentials",
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }
        _apply_ready_flags(payload, send_info)
        _health_cache_set(account_id, payload)
        return payload

    try:
        api_id_int = int(api_id)
    except Exception:
        api_id_int = None

    if not api_id_int:
        payload = {
            "ok": True,
            "account_id": account_id,
            "alive": True,
            "authorized": None,
            "last_error": "invalid_api_id",
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }
        _apply_ready_flags(payload, send_info)
        _health_cache_set(account_id, payload)
        return payload

    try:
        resp = _run_coro(_tg_status_check(account_id, api_id_int, api_hash), timeout=40)
        payload = {
            "ok": True,
            "account_id": account_id,
            "alive": True,
            "authorized": bool(resp.get("authorized")),
            "last_error": resp.get("error"),
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }
    except Exception as e:
        payload = {
            "ok": True,
            "account_id": account_id,
            "alive": False,
            "authorized": False,
            "last_error": str(e),
            "last_check_at": now_epoch(),
            **listener_info,
            **webhook_info,
            **send_info,
        }

    _apply_ready_flags(payload, send_info)
    _health_cache_set(account_id, payload)
    return payload


async def _tg_disconnect_safely(client: TelegramClient):
    try:
        await client.disconnect()
    except Exception:
        pass


async def _tg_status_check(account_id: str, api_id: int, api_hash: str) -> Dict[str, Any]:
    acc = read_account(account_id) or {}
    session_path = _resolve_session_path(account_id, acc)
    if not os.path.exists(session_path):
        return {"ok": True, "authorized": False, "session_exists": False}

    fps_cfg = get_fingerprints_cfg()
    fid = acc.get("fingerprint_id") or fps_cfg.get("default_id")
    fp = get_fingerprint_profile(fps_cfg, fid)
    client = build_telegram_client(session_path, api_id, api_hash, fp)
    try:
        await client.connect()
        me = await client.get_me()
        authorized = me is not None
        return {"ok": True, "authorized": bool(authorized), "session_exists": True}
    except Exception as e:
        return {"ok": True, "authorized": False, "session_exists": True, "error": str(e)}
    finally:
        await _tg_disconnect_safely(client)


async def _tg_send_text(account_id: str, chat_id: Any, text: str, reply_to: Optional[int]) -> Dict[str, Any]:
    acc = read_account(account_id)
    if not acc:
        return {"ok": False, "error": "not_found"}
    session_path = _resolve_session_path(account_id, acc)
    if not os.path.exists(session_path):
        return {"ok": False, "error": "session_missing"}

    api_id = acc.get("api_id")
    api_hash = str(acc.get("api_hash") or "").strip()
    try:
        api_id_int = int(api_id)
    except Exception:
        return {"ok": False, "error": "invalid_api_id"}
    if not api_hash:
        return {"ok": False, "error": "invalid_api_hash"}

    fps_cfg = get_fingerprints_cfg()
    fid = acc.get("fingerprint_id") or fps_cfg.get("default_id")
    fp = get_fingerprint_profile(fps_cfg, fid)
    client = build_telegram_client(session_path, api_id_int, api_hash, fp)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            _set_account_last_error(account_id, "unauthorized")
            return {"ok": False, "error": "unauthorized", "detail": "need_login"}
        target = _resolve_peer_for_send(acc, chat_id)
        msg = await client.send_message(target, text, reply_to=reply_to)
        return {"ok": True, "message_id": getattr(msg, "id", None)}
    except FloodWaitError as e:
        _set_account_rate_limited(account_id, int(e.seconds))
        return {"ok": False, "error": "rate_limited", "reason": "FLOOD_WAIT", "retry_after": int(e.seconds)}
    except (AuthKeyUnregisteredError, SessionRevokedError):
        _set_account_last_error(account_id, "session_revoked")
        return {"ok": False, "error": "session_revoked"}
    except Exception as e:
        _set_account_last_error(account_id, "send_failed")
        detail = f"{e.__class__.__name__}: {str(e)}".strip()
        _log_debug(f"send_text error account_id={account_id} error={detail}")
        return {"ok": False, "error": "send_failed", "detail": detail}
    finally:
        await _tg_disconnect_safely(client)


async def _tg_send_file(
    account_id: str,
    chat_id: Any,
    file_path: str,
    caption: Optional[str] = None,
    reply_to: Optional[int] = None,
    **kwargs,
) -> Dict[str, Any]:
    acc = read_account(account_id)
    if not acc:
        return {"ok": False, "error": "not_found"}
    session_path = _resolve_session_path(account_id, acc)
    if not os.path.exists(session_path):
        return {"ok": False, "error": "session_missing"}
    if not file_path or not os.path.exists(file_path):
        return {"ok": False, "error": "file_not_found"}
    if not _allowed_file_path(file_path):
        return {"ok": False, "error": "file_not_allowed"}

    api_id = acc.get("api_id")
    api_hash = str(acc.get("api_hash") or "").strip()
    try:
        api_id_int = int(api_id)
    except Exception:
        return {"ok": False, "error": "invalid_api_id"}
    if not api_hash:
        return {"ok": False, "error": "invalid_api_hash"}

    fps_cfg = get_fingerprints_cfg()
    fid = acc.get("fingerprint_id") or fps_cfg.get("default_id")
    fp = get_fingerprint_profile(fps_cfg, fid)
    client = build_telegram_client(session_path, api_id_int, api_hash, fp)
    try:
        await client.connect()
        if not await client.is_user_authorized():
            _set_account_last_error(account_id, "unauthorized")
            return {"ok": False, "error": "unauthorized", "detail": "need_login"}
        send_kwargs = dict(kwargs)
        if _is_gif_file(file_path):
            attrs = list(send_kwargs.get("attributes") or [])
            attrs.append(DocumentAttributeAnimated())
            send_kwargs["attributes"] = attrs
            send_kwargs.setdefault("mime_type", "image/gif")
        target = _resolve_peer_for_send(acc, chat_id)
        msg = await client.send_file(
            target,
            file_path,
            caption=caption or None,
            reply_to=reply_to,
            **send_kwargs,
        )
        return {"ok": True, "message_id": getattr(msg, "id", None)}
    except FloodWaitError as e:
        _set_account_rate_limited(account_id, int(e.seconds))
        return {"ok": False, "error": "rate_limited", "reason": "FLOOD_WAIT", "retry_after": int(e.seconds)}
    except (AuthKeyUnregisteredError, SessionRevokedError):
        _set_account_last_error(account_id, "session_revoked")
        return {"ok": False, "error": "session_revoked"}
    except Exception as e:
        _set_account_last_error(account_id, "send_failed")
        detail = f"{e.__class__.__name__}: {str(e)}".strip()
        _log_debug(f"send_file error account_id={account_id} error={detail}")
        return {"ok": False, "error": "send_failed", "detail": detail}
    finally:
        await _tg_disconnect_safely(client)


async def _tg_send_code(account_id: str, phone: str, api_id: int, api_hash: str) -> Dict[str, Any]:
    acc = read_account(account_id) or {}
    session_path = _resolve_session_path(account_id, acc)
    fps_cfg = get_fingerprints_cfg()
    fid = acc.get("fingerprint_id") or fps_cfg.get("default_id")
    fp = get_fingerprint_profile(fps_cfg, fid)
    client = build_telegram_client(session_path, api_id, api_hash, fp)

    await client.connect()
    sent = await client.send_code_request(phone)

    with tg_state_lock:
        tg_login_state[account_id] = {
            "client": client,
            "phone": phone,
            "api_id": api_id,
            "api_hash": api_hash,
            "step": "code_sent",
            "phone_code_hash": getattr(sent, "phone_code_hash", None),
            "ts": now_epoch()
        }

    return {"ok": True, "step": "code_sent"}


async def _tg_verify_code(account_id: str, code: str) -> Dict[str, Any]:
    with tg_state_lock:
        st = tg_login_state.get(account_id)

    if not st:
        return {"ok": False, "error": "no_pending_login"}

    client: TelegramClient = st["client"]
    phone = st["phone"]
    phone_code_hash = st.get("phone_code_hash")

    try:
        await client.sign_in(phone=phone, code=code, phone_code_hash=phone_code_hash)
        # autorizado
        with tg_state_lock:
            tg_login_state[account_id]["step"] = "authorized"
        await _tg_disconnect_safely(client)
        with tg_state_lock:
            tg_login_state.pop(account_id, None)
        return {"ok": True, "authorized": True}
    except SessionPasswordNeededError:
        with tg_state_lock:
            tg_login_state[account_id]["step"] = "2fa_required"
        return {"ok": True, "step": "2fa_required"}
    except PhoneCodeInvalidError:
        return {"ok": False, "error": "invalid_code"}
    except Exception as e:
        return {"ok": False, "error": "verify_failed", "detail": str(e)}


async def _tg_2fa(account_id: str, password: str) -> Dict[str, Any]:
    with tg_state_lock:
        st = tg_login_state.get(account_id)

    if not st:
        return {"ok": False, "error": "no_pending_login"}

    client: TelegramClient = st["client"]

    try:
        await client.sign_in(password=password)
        with tg_state_lock:
            tg_login_state[account_id]["step"] = "authorized"
        await _tg_disconnect_safely(client)
        with tg_state_lock:
            tg_login_state.pop(account_id, None)
        return {"ok": True, "authorized": True}
    except Exception as e:
        return {"ok": False, "error": "2fa_failed", "detail": str(e)}


# =========================================================
# Routes - Public
# =========================================================
@app.get("/health")
def health():
    cfg = load_config()
    acc_count = len(list_accounts())
    return jsonify({
        "ok": True,
        "version": "4.0",
        "time": now_epoch(),
        "server": cfg.get("server", {}),
        "accounts_count": acc_count
    })


@app.get("/")
def index():
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return send_from_directory(STATIC_DIR, "index.html")
    return "<h1>static/index.html nÃ£o encontrado</h1>", 404


@app.get("/api_explorer.html")
@require_admin_session
def api_explorer():
    return send_from_directory(STATIC_DIR, "api_explorer.html")


@app.get("/api-explorer")
@require_admin_session
def api_explorer_route():
    return send_from_directory(STATIC_DIR, "api_explorer.html")


# =========================================================
# Auth (cookie)
# =========================================================
@app.post("/api/auth/login")
def auth_login():
    cfg = load_config()
    data = request.get_json(silent=True) or {}
    user = str(data.get("user", "")).strip()
    pwd = str(data.get("pass", "")).strip()

    if user == cfg["admin"].get("user") and pwd == cfg["admin"].get("pass_plain"):
        session_val = make_session_value(cfg)
        resp = jsonify({"ok": True, "logged": True})
        resp.set_cookie(
            COOKIE_NAME,
            session_val,
            max_age=COOKIE_MAX_AGE,
            httponly=True,
            samesite="Lax",
        )
        return resp

    return jsonify({"ok": False, "error": "invalid_credentials"}), 401


@app.post("/api/auth/logout")
def auth_logout():
    resp = jsonify({"ok": True})
    resp.set_cookie(COOKIE_NAME, "", max_age=0)
    return resp


@app.get("/api/auth/me")
def auth_me():
    cfg = load_config()
    if not is_logged_in(cfg, request):
        return jsonify({"ok": True, "logged": False})
    return jsonify({"ok": True, "logged": True, "user": cfg["admin"].get("user", "admin")})


# =========================================================
# Listener config
# =========================================================
@app.get("/api/config/listener")
@require_api_access
def get_listener_config_route():
    return jsonify({"ok": True, "listener": get_listener_cfg()})


@app.post("/api/config/listener")
@require_api_access
def set_listener_config_route():
    data = request.get_json(silent=True) or {}
    cfg = load_config()
    current = _normalize_listener_config(cfg.get("listener", {}))

    updates: Dict[str, bool] = {}
    new_keys = (
        "enabled",
        "forward_private",
        "forward_groups",
        "forward_channels",
        "download_media_private",
        "download_media_groups",
        "download_media_channels",
    )
    for key in new_keys:
        if key in data:
            parsed = _parse_bool(data.get(key))
            if parsed is None:
                return jsonify({"ok": False, "error": "invalid_bool", "field": key}), 400
            updates[key] = parsed

    if "private_only" in data:
        parsed = _parse_bool(data.get("private_only"))
        if parsed is None:
            return jsonify({"ok": False, "error": "invalid_bool", "field": "private_only"}), 400
        if parsed:
            updates["forward_groups"] = False
            updates["forward_channels"] = False
            updates["download_media_groups"] = False
            updates["download_media_channels"] = False

    if "ignore_groups" in data:
        parsed = _parse_bool(data.get("ignore_groups"))
        if parsed is None:
            return jsonify({"ok": False, "error": "invalid_bool", "field": "ignore_groups"}), 400
        val = not parsed
        updates["forward_groups"] = val
        updates["download_media_groups"] = val

    if "ignore_channels" in data:
        parsed = _parse_bool(data.get("ignore_channels"))
        if parsed is None:
            return jsonify({"ok": False, "error": "invalid_bool", "field": "ignore_channels"}), 400
        val = not parsed
        updates["forward_channels"] = val
        updates["download_media_channels"] = val

    if not updates:
        return jsonify({"ok": False, "error": "no_fields"}), 400

    prev_enabled = bool(current.get("enabled", True))
    current.update(updates)
    cfg["listener"] = current
    save_config(cfg)
    _log_debug(f"Listener config updated {updates}")

    new_enabled = bool(cfg["listener"].get("enabled", True))
    if prev_enabled and not new_enabled:
        _log_debug("Listener disabled by config - stopping listeners")
        stop_all_listeners()
    elif (not prev_enabled) and new_enabled:
        _log_debug("Listener enabled by config - starting listeners")
        bootstrap_listeners()

    return jsonify({"ok": True, "listener": get_listener_cfg()})


# =========================================================
# Token (admin session)
# =========================================================
@app.get("/api/token")
@require_admin_session
def get_token():
    cfg = load_config()
    return jsonify({"ok": True, "bearer_token": cfg.get("api", {}).get("bearer_token", "")})


@app.post("/api/token/rotate")
@require_admin_session
def rotate_token():
    cfg = load_config()
    data = request.get_json(silent=True) or {}
    pass_plain = str(data.get("pass_plain") or "").strip()
    if not pass_plain or pass_plain != str(cfg.get("admin", {}).get("pass_plain") or ""):
        return jsonify({"ok": False, "error": "invalid_password"}), 401
    cfg.setdefault("api", {})
    cfg["api"]["bearer_token"] = secrets.token_urlsafe(48)
    save_config(cfg)
    return jsonify({"ok": True, "bearer_token": cfg["api"]["bearer_token"]})


@app.post("/api/token")
@require_admin_session
def set_token():
    cfg = load_config()
    data = request.get_json(silent=True) or {}
    token = str(data.get("bearer_token", "")).strip()
    if not token or len(token) < 16:
        return jsonify({"ok": False, "error": "token_too_short"}), 400
    cfg.setdefault("api", {})
    cfg["api"]["bearer_token"] = token
    save_config(cfg)
    return jsonify({"ok": True})


# =========================================================
# Fingerprints
# =========================================================
@app.get("/api/fingerprints")
@require_api_access
def list_fingerprints_route():
    fps_cfg = get_fingerprints_cfg()
    fps = fps_cfg.get("profiles", []) or []
    items = [
        {"id": p.get("id"), "label": _normalize_fingerprint_label(p.get("label"))}
        for p in fps if p.get("id")
    ]
    return jsonify({"ok": True, "items": items, "default_id": fps_cfg.get("default_id")})


@app.get("/api/fingerprints/<fingerprint_id>")
@require_api_access
def get_fingerprint_route(fingerprint_id: str):
    fps = get_fingerprints_cfg().get("profiles", []) or []
    for p in fps:
        if p.get("id") == fingerprint_id:
            item = dict(p)
            item["label"] = _normalize_fingerprint_label(item.get("label"))
            return jsonify({"ok": True, "item": item})
    return jsonify({"ok": False, "error": "not_found"}), 404


# =========================================================
# STEP 1 â€” Accounts CRUD
# =========================================================
@app.get("/api/accounts")
@require_api_access
def accounts_list_route():
    return jsonify({"ok": True, "items": list_accounts()})


@app.post("/api/accounts")
@require_api_access
def accounts_create_route():
    cfg = load_config()
    data = request.get_json(silent=True) or {}

    account_id = str(data.get("id", "")).strip()
    phone = str(data.get("phone", "")).strip()
    fingerprint_id = str(data.get("fingerprint_id", "")).strip()
    webhook_url = str(data.get("webhook_url", "")).strip()

    if not account_id or not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400
    if not phone:
        return jsonify({"ok": False, "error": "missing_phone"}), 400

    if not fingerprint_id:
        fingerprint_id = default_fingerprint_id(cfg) or ""
    if fingerprint_id and not validate_fingerprint(cfg, fingerprint_id):
        return jsonify({"ok": False, "error": "invalid_fingerprint_id"}), 400

    if os.path.exists(account_json_path(account_id)):
        return jsonify({"ok": False, "error": "id_already_exists"}), 409

    item = {
        "id": account_id,
        "phone": phone,
        "fingerprint_id": fingerprint_id,
        "webhook_url": webhook_url,
        "session_path": account_session_rel(account_id),
        "created_at": now_epoch(),
        "updated_at": now_epoch(),
    }

    write_account(account_id, item)
    _health_cache_clear(account_id)
    return jsonify({"ok": True, "item": item}), 201


@app.route("/api/accounts/<account_id>", methods=["PUT", "PATCH"])
@require_api_access
def accounts_update_route(account_id: str):
    cfg = load_config()
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    current = read_account(account_id)
    if not current:
        return jsonify({"ok": False, "error": "not_found"}), 404

    data = request.get_json(silent=True) or {}

    if "phone" in data:
        phone = str(data.get("phone") or "").strip()
        if not phone:
            return jsonify({"ok": False, "error": "phone_empty"}), 400
        current["phone"] = phone

    if "fingerprint_id" in data:
        fid = str(data.get("fingerprint_id") or "").strip()
        if fid and not validate_fingerprint(cfg, fid):
            return jsonify({"ok": False, "error": "invalid_fingerprint_id"}), 400
        current["fingerprint_id"] = fid

    if "webhook_url" in data:
        current["webhook_url"] = str(data.get("webhook_url") or "").strip()

    current["updated_at"] = now_epoch()
    write_account(account_id, current)
    _health_cache_clear(account_id)
    return jsonify({"ok": True, "item": current})


@app.delete("/api/accounts/<account_id>")
@require_api_access
def accounts_delete_route(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    current = read_account(account_id)
    if not current:
        return jsonify({"ok": False, "error": "not_found"}), 404

    stop_listener_for_account(account_id)
    delete_account_files(account_id)
    _health_cache_clear(account_id)
    return jsonify({"ok": True})


# =========================================================
# STEP 2 â€” Telethon connect por conta
# =========================================================
@app.post("/api/accounts/<account_id>/connect/start")
@require_api_access
def tg_connect_start(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    acc = read_account(account_id)
    if not acc:
        return jsonify({"ok": False, "error": "not_found"}), 404

    data = request.get_json(silent=True) or {}
    try:
        api_id = int(data.get("api_id"))
    except Exception:
        return jsonify({"ok": False, "error": "invalid_api_id"}), 400

    api_hash = str(data.get("api_hash") or "").strip()
    phone = str(data.get("phone") or acc.get("phone") or "").strip()

    if not api_hash:
        return jsonify({"ok": False, "error": "missing_api_hash"}), 400
    if not phone:
        return jsonify({"ok": False, "error": "missing_phone"}), 400

    # salva phone/credenciais no JSON para status real
    changed = False
    if phone != (acc.get("phone") or ""):
        acc["phone"] = phone
        changed = True
    if api_id and str(api_id) != str(acc.get("api_id") or ""):
        acc["api_id"] = int(api_id)
        changed = True
    if api_hash and api_hash != str(acc.get("api_hash") or ""):
        acc["api_hash"] = api_hash
        changed = True
    if changed:
        acc["updated_at"] = now_epoch()
        write_account(account_id, acc)
        _health_cache_clear(account_id)

    try:
        resp = _run_coro(_tg_send_code(account_id, phone, api_id, api_hash), timeout=60)
        return jsonify(resp)
    except PhoneNumberInvalidError:
        return jsonify({"ok": False, "error": "invalid_phone"}), 400
    except ApiIdInvalidError:
        return jsonify({"ok": False, "error": "invalid_api_credentials"}), 400
    except Exception as e:
        return jsonify({"ok": False, "error": "start_failed", "detail": str(e)}), 500


@app.post("/api/accounts/<account_id>/connect/verify")
@require_api_access
def tg_connect_verify(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    data = request.get_json(silent=True) or {}
    code = str(data.get("code") or "").strip()
    if not code:
        return jsonify({"ok": False, "error": "missing_code"}), 400

    try:
        resp = _run_coro(_tg_verify_code(account_id, code), timeout=60)
        if resp.get("ok") and resp.get("authorized"):
            if not listener_enabled():
                _log_debug(f"Listener disabled by config account_id={account_id}")
                return jsonify({"ok": False, "error": "listener_disabled"}), 400
            start_listener_for_account(account_id)
        status_code = 200 if resp.get("ok") else 400
        return jsonify(resp), status_code
    except Exception as e:
        return jsonify({"ok": False, "error": "verify_failed", "detail": str(e)}), 500


@app.post("/api/accounts/<account_id>/connect/2fa")
@require_api_access
def tg_connect_2fa(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    data = request.get_json(silent=True) or {}
    password = str(data.get("password") or "")
    if not password:
        return jsonify({"ok": False, "error": "missing_password"}), 400

    try:
        resp = _run_coro(_tg_2fa(account_id, password), timeout=60)
        if resp.get("ok") and resp.get("authorized"):
            if not listener_enabled():
                _log_debug(f"Listener disabled by config account_id={account_id}")
                return jsonify({"ok": False, "error": "listener_disabled"}), 400
            start_listener_for_account(account_id)
        status_code = 200 if resp.get("ok") else 400
        return jsonify(resp), status_code
    except Exception as e:
        return jsonify({"ok": False, "error": "2fa_failed", "detail": str(e)}), 500


# =========================================================
# Send queue (SQLite/Redis)
# =========================================================
_SEND_INT_FIELDS = {
    "created_at",
    "updated_at",
    "attempts",
    "floodwait_seconds",
}


def _send_job_key(job_id: str) -> str:
    return _redis_key("send_job", job_id)


def _send_jobs_all_key() -> str:
    return _redis_key("send_jobs", "all")


def _send_jobs_pending_key(account_id: str) -> str:
    return _redis_key("send_jobs", account_id, "pending")


def _send_jobs_sending_key(account_id: str) -> str:
    return _redis_key("send_jobs", account_id, "sending")


def _send_counts_key(account_id: str) -> str:
    return _redis_key("send_counts", account_id)


def _send_accounts_pending_key() -> str:
    return _redis_key("send_accounts", "pending")


def _send_account_key(account_id: str) -> str:
    return _redis_key("send_account", account_id)


def _redis_send_job_to_dict(data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not data:
        return None
    out: Dict[str, Any] = {}
    for k, v in data.items():
        if k in _SEND_INT_FIELDS and v not in (None, ""):
            try:
                out[k] = int(v)
            except Exception:
                out[k] = 0
        else:
            out[k] = v
    return out


def _redis_delete_send_job(r, job_id: str, data: Dict[str, Any]) -> None:
    account_id = data.get("account_id") or ""
    status = data.get("status") or ""
    pipe = r.pipeline()
    pipe.zrem(_send_jobs_all_key(), job_id)
    if account_id:
        pipe.zrem(_send_jobs_pending_key(account_id), job_id)
        pipe.zrem(_send_jobs_sending_key(account_id), job_id)
        if status:
            pipe.hincrby(_send_counts_key(account_id), status, -1)
    pipe.delete(_send_job_key(job_id))
    pipe.execute()
    if account_id and r.zcard(_send_jobs_pending_key(account_id)) == 0:
        r.srem(_send_accounts_pending_key(), account_id)


def _send_lock_key(account_id: str) -> str:
    return _redis_key("send_lock", account_id)


def _redis_acquire_send_lock(account_id: str) -> Optional[str]:
    r = _redis_client() if _redis_enabled() else None
    if not r:
        return None
    token = uuid.uuid4().hex
    ok = r.set(_send_lock_key(account_id), token, nx=True, ex=60)
    return token if ok else None


def _redis_release_send_lock(account_id: str, token: Optional[str]) -> None:
    if not token:
        return
    r = _redis_client() if _redis_enabled() else None
    if not r:
        return
    script = """
    if redis.call("get", KEYS[1]) == ARGV[1] then
        return redis.call("del", KEYS[1])
    end
    return 0
    """
    try:
        r.eval(script, 1, _send_lock_key(account_id), token)
    except Exception:
        pass
def _db_connect() -> sqlite3.Connection:
    conn = sqlite3.connect(str(SEND_DB_PATH), timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def db_init() -> None:
    if _redis_enabled():
        if _redis_client() is not None:
            return
        _log_debug("redis_enabled_but_unavailable using_sqlite_fallback")

    os.makedirs(DATA_DIR, exist_ok=True)
    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=30000")
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS send_jobs (
                    job_id TEXT PRIMARY KEY,
                    account_id TEXT NOT NULL,
                    type TEXT NOT NULL,
                    chat_id TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    attempts INTEGER NOT NULL DEFAULT 0,
                    result_json TEXT NULL,
                    error TEXT NULL,
                    detail TEXT NULL,
                    floodwait_seconds INTEGER NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS send_accounts (
                    account_id TEXT PRIMARY KEY,
                    paused_until INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT NULL,
                    last_error_at INTEGER NULL,
                    last_ok_at INTEGER NULL,
                    last_send_at INTEGER NULL,
                    updated_at INTEGER NOT NULL
                )
                """
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_send_jobs_account_status_created "
                "ON send_jobs(account_id, status, created_at)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_send_jobs_created_at "
                "ON send_jobs(created_at)"
            )
        finally:
            conn.close()


def _row_to_dict(row: Optional[sqlite3.Row]) -> Optional[Dict[str, Any]]:
    if not row:
        return None
    return {k: row[k] for k in row.keys()}


def db_ensure_account(account_id: str) -> None:
    now = now_epoch()
    r = _redis_client() if _redis_enabled() else None
    if r:
        key = _send_account_key(account_id)
        pipe = r.pipeline()
        pipe.hsetnx(key, "account_id", account_id)
        pipe.hsetnx(key, "paused_until", 0)
        pipe.hsetnx(key, "last_error", "")
        pipe.hsetnx(key, "last_error_at", 0)
        pipe.hsetnx(key, "last_ok_at", 0)
        pipe.hsetnx(key, "last_send_at", 0)
        pipe.hset(key, "updated_at", now)
        pipe.execute()
        return

    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute(
                """
                INSERT INTO send_accounts (account_id, updated_at)
                VALUES (?, ?)
                ON CONFLICT(account_id) DO UPDATE SET updated_at=excluded.updated_at
                """,
                (account_id, now),
            )
            conn.commit()
        finally:
            conn.close()


def db_insert_job(
    job_id: str,
    account_id: str,
    job_type: str,
    chat_id: str,
    payload: Dict[str, Any],
    status: str = "PENDING",
) -> None:
    now = now_epoch()
    payload_json = json.dumps(payload, ensure_ascii=False)
    r = _redis_client() if _redis_enabled() else None
    if r:
        job_key = _send_job_key(job_id)
        pending_key = _send_jobs_pending_key(account_id)
        all_key = _send_jobs_all_key()
        counts_key = _send_counts_key(account_id)
        pipe = r.pipeline()
        pipe.hset(job_key, mapping={
            "job_id": job_id,
            "account_id": account_id,
            "type": job_type,
            "chat_id": chat_id,
            "payload_json": payload_json,
            "status": status,
            "created_at": now,
            "updated_at": now,
            "attempts": 0,
            "result_json": "",
            "error": "",
            "detail": "",
            "floodwait_seconds": "",
        })
        if status == "PENDING":
            pipe.zadd(pending_key, {job_id: now})
            pipe.sadd(_send_accounts_pending_key(), account_id)
        pipe.zadd(all_key, {job_id: now})
        pipe.hincrby(counts_key, status, 1)
        pipe.execute()
        return

    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute(
                """
                INSERT INTO send_jobs
                (job_id, account_id, type, chat_id, payload_json, status, created_at, updated_at, attempts)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (job_id, account_id, job_type, chat_id, payload_json, status, now, now),
            )
            conn.commit()
        finally:
            conn.close()


def db_mark_sending(job_id: str) -> None:
    now = now_epoch()
    r = _redis_client() if _redis_enabled() else None
    if r:
        job_key = _send_job_key(job_id)
        data = r.hgetall(job_key)
        if not data:
            return
        account_id = data.get("account_id") or ""
        cur_status = data.get("status") or ""
        created_at = data.get("created_at") or now
        pending_key = _send_jobs_pending_key(account_id)
        sending_key = _send_jobs_sending_key(account_id)
        counts_key = _send_counts_key(account_id)
        pipe = r.pipeline()
        if cur_status and cur_status != "SENDING":
            pipe.hincrby(counts_key, cur_status, -1)
            pipe.hincrby(counts_key, "SENDING", 1)
        pipe.zrem(pending_key, job_id)
        pipe.zadd(sending_key, {job_id: int(created_at)})
        pipe.hincrby(job_key, "attempts", 1)
        pipe.hset(job_key, mapping={"status": "SENDING", "updated_at": now})
        pipe.execute()
        if r.zcard(pending_key) == 0:
            r.srem(_send_accounts_pending_key(), account_id)
        return

    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute(
                """
                UPDATE send_jobs
                SET status='SENDING', attempts=attempts+1, updated_at=?
                WHERE job_id=?
                """,
                (now, job_id),
            )
            conn.commit()
        finally:
            conn.close()


def db_update_job(job_id: str, **fields: Any) -> None:
    if not fields:
        return
    now = now_epoch()
    r = _redis_client() if _redis_enabled() else None
    if r:
        job_key = _send_job_key(job_id)
        data = r.hgetall(job_key)
        if not data:
            return
        account_id = data.get("account_id") or ""
        cur_status = data.get("status") or ""
        new_status = fields.get("status", cur_status)
        created_at = int(data.get("created_at") or now)
        pending_key = _send_jobs_pending_key(account_id)
        sending_key = _send_jobs_sending_key(account_id)
        counts_key = _send_counts_key(account_id)
        update_fields = dict(fields)
        update_fields["updated_at"] = now

        pipe = r.pipeline()
        if new_status != cur_status and account_id:
            if cur_status:
                pipe.hincrby(counts_key, cur_status, -1)
            if new_status:
                pipe.hincrby(counts_key, new_status, 1)

            if cur_status == "PENDING":
                pipe.zrem(pending_key, job_id)
            if cur_status == "SENDING":
                pipe.zrem(sending_key, job_id)

            if new_status == "PENDING":
                pipe.zadd(pending_key, {job_id: created_at})
                pipe.sadd(_send_accounts_pending_key(), account_id)
            elif new_status == "SENDING":
                pipe.zadd(sending_key, {job_id: created_at})
            else:
                pipe.zrem(pending_key, job_id)
                pipe.zrem(sending_key, job_id)

        pipe.hset(job_key, mapping=update_fields)
        pipe.execute()

        if account_id and r.zcard(pending_key) == 0:
            r.srem(_send_accounts_pending_key(), account_id)
        return

    fields["updated_at"] = now
    columns = ", ".join([f"{k}=?" for k in fields.keys()])
    values = list(fields.values()) + [job_id]
    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute(f"UPDATE send_jobs SET {columns} WHERE job_id=?", values)
            conn.commit()
        finally:
            conn.close()


def db_get_next_pending_job(account_id: str) -> Optional[Dict[str, Any]]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        pending_key = _send_jobs_pending_key(account_id)
        ids = r.zrange(pending_key, 0, 0)
        if not ids:
            return None
        data = r.hgetall(_send_job_key(ids[0]))
        return _redis_send_job_to_dict(data)

    with _send_db_lock:
        conn = _db_connect()
        try:
            row = conn.execute(
                """
                SELECT * FROM send_jobs
                WHERE account_id=? AND status='PENDING'
                ORDER BY created_at ASC
                LIMIT 1
                """,
                (account_id,),
            ).fetchone()
            return _row_to_dict(row)
        finally:
            conn.close()


def db_get_job(job_id: str) -> Optional[Dict[str, Any]]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        data = r.hgetall(_send_job_key(job_id))
        return _redis_send_job_to_dict(data)

    with _send_db_lock:
        conn = _db_connect()
        try:
            row = conn.execute("SELECT * FROM send_jobs WHERE job_id=?", (job_id,)).fetchone()
            return _row_to_dict(row)
        finally:
            conn.close()


def db_list_jobs(account_id: str, limit: int = 50) -> List[Dict[str, Any]]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        pending_ids = r.zrevrange(_send_jobs_pending_key(account_id), 0, limit - 1)
        sending_ids = r.zrevrange(_send_jobs_sending_key(account_id), 0, limit - 1)
        ids = list(dict.fromkeys(pending_ids + sending_ids))
        items: List[Dict[str, Any]] = []
        for job_id in ids:
            data = r.hgetall(_send_job_key(job_id))
            item = _redis_send_job_to_dict(data)
            if item:
                items.append(item)
        items.sort(key=lambda x: int(x.get("created_at") or 0), reverse=True)
        return items[:limit]

    with _send_db_lock:
        conn = _db_connect()
        try:
            rows = conn.execute(
                """
                SELECT * FROM send_jobs
                WHERE account_id=? AND status IN ('PENDING','SENDING')
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (account_id, limit),
            ).fetchall()
            return [_row_to_dict(row) for row in rows if row]
        finally:
            conn.close()


def db_list_all_jobs(limit: int = 200) -> List[Dict[str, Any]]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        ids = r.zrevrange(_send_jobs_all_key(), 0, limit - 1)
        items: List[Dict[str, Any]] = []
        for job_id in ids:
            data = r.hgetall(_send_job_key(job_id))
            item = _redis_send_job_to_dict(data)
            if item:
                items.append(item)
        items.sort(key=lambda x: int(x.get("created_at") or 0), reverse=True)
        return items[:limit]

    with _send_db_lock:
        conn = _db_connect()
        try:
            rows = conn.execute(
                """
                SELECT * FROM send_jobs
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
            return [_row_to_dict(row) for row in rows if row]
        finally:
            conn.close()


def db_counts_by_status(account_id: str) -> Dict[str, int]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        counts_raw = r.hgetall(_send_counts_key(account_id))
        counts = {k: int(v or 0) for k, v in counts_raw.items()}
        counts["PENDING"] = int(r.zcard(_send_jobs_pending_key(account_id)))
        counts["SENDING"] = int(r.zcard(_send_jobs_sending_key(account_id)))
        return counts

    with _send_db_lock:
        conn = _db_connect()
        try:
            rows = conn.execute(
                "SELECT status, COUNT(*) AS cnt FROM send_jobs WHERE account_id=? GROUP BY status",
                (account_id,),
            ).fetchall()
            return {row["status"]: int(row["cnt"]) for row in rows}
        finally:
            conn.close()


def db_count_pending(account_id: str) -> int:
    r = _redis_client() if _redis_enabled() else None
    if r:
        pending = int(r.zcard(_send_jobs_pending_key(account_id)))
        sending = int(r.zcard(_send_jobs_sending_key(account_id)))
        return pending + sending

    with _send_db_lock:
        conn = _db_connect()
        try:
            row = conn.execute(
                "SELECT COUNT(*) AS cnt FROM send_jobs WHERE account_id=? AND status IN ('PENDING','SENDING')",
                (account_id,),
            ).fetchone()
            return int(row["cnt"] or 0) if row else 0
        finally:
            conn.close()


def db_accounts_with_pending() -> List[str]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        return [str(x) for x in r.smembers(_send_accounts_pending_key())]

    with _send_db_lock:
        conn = _db_connect()
        try:
            rows = conn.execute(
                "SELECT DISTINCT account_id FROM send_jobs WHERE status='PENDING'"
            ).fetchall()
            return [row["account_id"] for row in rows]
        finally:
            conn.close()


def db_get_account_state(account_id: str) -> Dict[str, Any]:
    r = _redis_client() if _redis_enabled() else None
    if r:
        key = _send_account_key(account_id)
        data = r.hgetall(key)
        if not data:
            now = now_epoch()
            r.hset(key, mapping={
                "account_id": account_id,
                "paused_until": 0,
                "last_error": "",
                "last_error_at": 0,
                "last_ok_at": 0,
                "last_send_at": 0,
                "updated_at": now,
            })
            return {
                "account_id": account_id,
                "paused_until": 0,
                "last_error": None,
                "last_error_at": None,
                "last_ok_at": None,
                "last_send_at": None,
                "updated_at": now,
            }
        return {
            "account_id": data.get("account_id") or account_id,
            "paused_until": int(data.get("paused_until") or 0),
            "last_error": data.get("last_error") or None,
            "last_error_at": int(data.get("last_error_at") or 0) or None,
            "last_ok_at": int(data.get("last_ok_at") or 0) or None,
            "last_send_at": int(data.get("last_send_at") or 0) or None,
            "updated_at": int(data.get("updated_at") or 0),
        }

    with _send_db_lock:
        conn = _db_connect()
        try:
            row = conn.execute(
                "SELECT * FROM send_accounts WHERE account_id=?",
                (account_id,),
            ).fetchone()
            if not row:
                now = now_epoch()
                conn.execute(
                    "INSERT INTO send_accounts (account_id, updated_at) VALUES (?, ?)",
                    (account_id, now),
                )
                conn.commit()
                return {
                    "account_id": account_id,
                    "paused_until": 0,
                    "last_error": None,
                    "last_error_at": None,
                    "last_ok_at": None,
                    "last_send_at": None,
                    "updated_at": now,
                }
            return _row_to_dict(row) or {}
        finally:
            conn.close()


def db_set_pause(account_id: str, paused_until: int, last_error: Optional[str]) -> None:
    now = now_epoch()
    r = _redis_client() if _redis_enabled() else None
    if r:
        r.hset(
            _send_account_key(account_id),
            mapping={
                "account_id": account_id,
                "paused_until": int(paused_until),
                "last_error": last_error or "",
                "last_error_at": now,
                "updated_at": now,
            },
        )
        return

    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute(
                """
                INSERT INTO send_accounts (account_id, paused_until, last_error, last_error_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(account_id) DO UPDATE SET
                    paused_until=excluded.paused_until,
                    last_error=excluded.last_error,
                    last_error_at=excluded.last_error_at,
                    updated_at=excluded.updated_at
                """,
                (account_id, paused_until, last_error, now, now),
            )
            conn.commit()
        finally:
            conn.close()


def db_update_account_fields(account_id: str, **fields: Any) -> None:
    if not fields:
        return
    now = now_epoch()
    r = _redis_client() if _redis_enabled() else None
    if r:
        fields["updated_at"] = now
        fields["account_id"] = account_id
        r.hset(_send_account_key(account_id), mapping=fields)
        return

    fields["updated_at"] = now
    columns = ", ".join([f"{k}=?" for k in fields.keys()])
    values = list(fields.values()) + [account_id]
    with _send_db_lock:
        conn = _db_connect()
        try:
            conn.execute(
                f"""
                INSERT INTO send_accounts (account_id, updated_at)
                VALUES (?, ?)
                ON CONFLICT(account_id) DO UPDATE SET {columns}
                """,
                (account_id, fields["updated_at"], *values[:-1]),
            )
            conn.commit()
        finally:
            conn.close()


def _send_pause_jitter(cfg: Dict[str, Any]) -> int:
    try:
        min_sec = int(cfg.get("pause_jitter_min_sec") or 60)
        max_sec = int(cfg.get("pause_jitter_max_sec") or 300)
    except Exception:
        return 60
    if max_sec < min_sec:
        max_sec = min_sec
    return random.randint(min_sec, max_sec)


def _send_account_ready(account_id: str) -> bool:
    cfg = _send_cfg()
    state = db_get_account_state(account_id)
    now = now_epoch()
    paused_until = int(state.get("paused_until") or 0)
    if paused_until and now >= paused_until:
        db_update_account_fields(account_id, paused_until=0, last_error=None, last_error_at=None)
        _log_debug(f"SEND RESUMED account_id={account_id}")
    if paused_until and now < paused_until:
        return False
    try:
        interval = int(cfg.get("send_interval_sec") or 2)
    except Exception:
        interval = 2
    last_send_at = int(state.get("last_send_at") or 0)
    if last_send_at and now - last_send_at < max(1, interval):
        return False
    return True


def _send_worker(account_id: str, lock: threading.Lock, redis_lock_token: Optional[str] = None) -> None:
    try:
        job = db_get_next_pending_job(account_id)
        if not job:
            return

        cfg = _send_cfg()
        try:
            job_ttl = int(cfg.get("job_ttl_seconds") or 7200)
        except Exception:
            job_ttl = 7200
        created_at = int(job.get("created_at") or 0)
        if created_at and now_epoch() - created_at > job_ttl:
            db_update_job(job["job_id"], status="CANCELLED", error="expired", detail="job_ttl")
            return

        db_mark_sending(job["job_id"])
        payload = json.loads(job.get("payload_json") or "{}")
        chat_id = payload.get("chat_id")
        reply_to = payload.get("reply_to")
        result_json = None
        error = None
        detail = None
        floodwait_seconds = None

        if job.get("type") == "text":
            text = str(payload.get("text") or "")
            resp = _run_coro(_tg_send_text(account_id, chat_id, text, reply_to))
        else:
            file_path = str(payload.get("file_path") or "")
            url = str(payload.get("url") or "")
            caption = payload.get("caption")
            streaming = bool(payload.get("streaming", False))
            send_kwargs: Dict[str, Any] = {}
            if job.get("type") == "voice":
                send_kwargs["voice_note"] = True
            if job.get("type") == "video":
                send_kwargs["supports_streaming"] = streaming

            cache_info = {}
            if not file_path and url:
                dl = _download_url_to_media(url)
                if not dl.get("ok"):
                    resp = {"ok": False, "error": dl.get("error") or "download_failed", "detail": dl.get("detail")}
                else:
                    file_path = str(dl.get("path") or "")
                    cache_info = {
                        "cached": bool(dl.get("cached")),
                        "media_id": dl.get("media_id"),
                        "http_status_download": dl.get("http_status_download"),
                        "bytes_downloaded": dl.get("bytes_downloaded"),
                    }
                    resp = _run_coro(
                        _tg_send_file(account_id, chat_id, file_path, caption=caption, reply_to=reply_to, **send_kwargs)
                    )
            else:
                resp = _run_coro(
                    _tg_send_file(account_id, chat_id, file_path, caption=caption, reply_to=reply_to, **send_kwargs)
                )

            if resp.get("ok"):
                result_json = json.dumps({
                    "message_id": resp.get("message_id"),
                    **(cache_info or {}),
                }, ensure_ascii=False)
            elif resp.get("error") == "rate_limited":
                floodwait_seconds = int(resp.get("retry_after") or 0)
            else:
                error = resp.get("error") or "send_failed"
                detail = resp.get("detail") or ""

        if job.get("type") == "text" and resp.get("ok"):
            result_json = json.dumps({"message_id": resp.get("message_id")}, ensure_ascii=False)

        now = now_epoch()
        db_update_account_fields(account_id, last_send_at=now)

        if resp.get("ok"):
            db_update_job(job["job_id"], status="SENT", result_json=result_json, error=None, detail=None, floodwait_seconds=None)
            db_update_account_fields(account_id, last_ok_at=now, last_error=None, last_error_at=None)
            return

        if resp.get("error") == "rate_limited":
            floodwait_seconds = int(resp.get("retry_after") or 0)
            jitter = _send_pause_jitter(cfg)
            paused_until = now + floodwait_seconds + jitter
            db_set_pause(account_id, paused_until, "floodwait")
            db_update_job(
                job["job_id"],
                status="PENDING",
                error="floodwait",
                detail=f"pause_{floodwait_seconds}",
                floodwait_seconds=floodwait_seconds,
            )
            _log_debug(f"SEND FLOODWAIT account_id={account_id} seconds={floodwait_seconds} paused_until={paused_until}")
            return

        if resp.get("error") == "unauthorized":
            error = "unauthorized"
            detail = resp.get("detail") or ""
        elif not error:
            error = resp.get("error") or "send_failed"
            detail = resp.get("detail") or resp.get("reason") or ""

        db_update_job(job["job_id"], status="FAILED", error=error, detail=detail, floodwait_seconds=floodwait_seconds)
        db_update_account_fields(account_id, last_error=error, last_error_at=now)
    finally:
        try:
            lock.release()
        except Exception:
            pass
        _redis_release_send_lock(account_id, redis_lock_token)


def _send_dispatcher() -> None:
    while True:
        time.sleep(SEND_DISPATCH_INTERVAL_SEC)
        for account_id in db_accounts_with_pending():
            if not _send_account_ready(account_id):
                continue
            lock = _send_lock_for_account(account_id)
            if not lock.acquire(blocking=False):
                continue
            redis_token = None
            r = _redis_client() if _redis_enabled() else None
            if r:
                redis_token = _redis_acquire_send_lock(account_id)
                if not redis_token:
                    try:
                        lock.release()
                    except Exception:
                        pass
                    continue
            threading.Thread(target=_send_worker, args=(account_id, lock, redis_token), daemon=True).start()


def _send_cleanup_worker() -> None:
    while True:
        time.sleep(300)
        cfg = _send_cfg()
        try:
            job_ttl = int(cfg.get("job_ttl_seconds") or 7200)
        except Exception:
            job_ttl = 7200
        try:
            cleanup_after = int(cfg.get("cleanup_after_seconds") or 172800)
        except Exception:
            cleanup_after = 172800
        now = now_epoch()
        expire_before = now - job_ttl
        delete_before = now - cleanup_after

        r = _redis_client() if _redis_enabled() else None
        if r:
            all_key = _send_jobs_all_key()
            expired_ids = r.zrangebyscore(all_key, 0, expire_before)
            for job_id in expired_ids:
                data = r.hgetall(_send_job_key(job_id))
                if not data:
                    continue
                status = data.get("status") or ""
                if status in ("PENDING", "SENDING"):
                    db_update_job(job_id, status="CANCELLED", error="expired", detail="job_ttl")

            delete_ids = r.zrangebyscore(all_key, 0, delete_before)
            for job_id in delete_ids:
                data = r.hgetall(_send_job_key(job_id))
                if not data:
                    r.zrem(all_key, job_id)
                    continue
                if (data.get("status") or "") == "CANCELLED":
                    _redis_delete_send_job(r, job_id, data)
            continue

        with _send_db_lock:
            conn = _db_connect()
            try:
                conn.execute(
                    """
                    UPDATE send_jobs
                    SET status='CANCELLED', updated_at=?, error='expired', detail='job_ttl'
                    WHERE status IN ('PENDING','SENDING') AND created_at <= ?
                    """,
                    (now, expire_before),
                )
                conn.execute(
                    "DELETE FROM send_jobs WHERE status='CANCELLED' AND updated_at <= ?",
                    (delete_before,),
                )
                conn.commit()
            finally:
                conn.close()

db_init()
threading.Thread(target=_send_dispatcher, daemon=True).start()
threading.Thread(target=_send_cleanup_worker, daemon=True).start()

def _build_send_result(
    ok: bool,
    error: Optional[str] = None,
    detail: Optional[str] = None,
    message_id: Optional[int] = None,
    cached: Optional[bool] = None,
    media_id: Optional[str] = None,
    http_status_download: Optional[int] = None,
    bytes_downloaded: Optional[int] = None,
) -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "ok": ok,
        "sent": bool(ok),
        "status": "sent" if ok else "failed",
        "message_id": message_id if ok else None,
        "cached": cached,
        "media_id": media_id,
        "http_status_download": http_status_download,
        "bytes_downloaded": bytes_downloaded,
    }
    if not ok:
        result["error"] = error or "send_failed"
        result["detail"] = detail or ""
    return result


def _enqueue_send_job(
    account_id: str,
    job_type: str,
    chat_id: Any,
    payload: Dict[str, Any],
) -> Dict[str, Any]:
    cfg = _send_cfg()
    try:
        max_queue = int(cfg.get("max_queue_per_account") or 5000)
    except Exception:
        max_queue = 5000
    pending = db_count_pending(account_id)
    if pending >= max_queue:
        return {"ok": False, "error": "queue_full", "detail": "max_queue_per_account"}

    job_id = f"send_{uuid.uuid4().hex}"
    db_ensure_account(account_id)
    db_insert_job(job_id, account_id, job_type, str(chat_id), payload, status="PENDING")
    if _redis_enabled() and _redis_client():
        _log_debug(
            "Send queued via redis "
            f"account_id={account_id} chat_id={chat_id} type={job_type} job_id={job_id}"
        )
    else:
        _log_debug(
            "Send queued via sqlite "
            f"account_id={account_id} chat_id={chat_id} type={job_type} job_id={job_id}"
        )
    return {"ok": True, "job_id": job_id, "status": "PENDING"}


def _send_response_standard(resp: Dict[str, Any], cache_info: Optional[Dict[str, Any]] = None):
    cache_info = cache_info or {}
    cached = cache_info.get("cached")
    media_id = cache_info.get("media_id")
    http_status_download = cache_info.get("http_status_download")
    bytes_downloaded = cache_info.get("bytes_downloaded")

    if resp.get("ok"):
        payload = _build_send_result(
            True,
            message_id=resp.get("message_id"),
            cached=cached,
            media_id=media_id,
            http_status_download=http_status_download,
            bytes_downloaded=bytes_downloaded,
        )
        return jsonify(payload)

    err = resp.get("error") or "send_failed"
    detail = resp.get("detail") or resp.get("reason") or ""
    payload = _build_send_result(
        False,
        error=err,
        detail=detail,
        cached=cached,
        media_id=media_id,
        http_status_download=http_status_download,
        bytes_downloaded=bytes_downloaded,
    )
    if err == "unauthorized":
        status = 401
    elif err == "send_failed":
        status = 502
    elif err == "rate_limited":
        status = 429
    else:
        status = 400
    return jsonify(payload), status


@app.post("/api/send/text")
@require_api_access
def send_text_route():
    data = request.get_json(silent=True) or {}
    account_id = str(data.get("account_id") or "").strip()
    chat_id = data.get("chat_id")
    text = str(data.get("text") or "")
    reply_to = data.get("reply_to")

    if not account_id or chat_id is None or not text:
        payload = _build_send_result(
            False,
            error="missing_fields",
            detail="account_id/chat_id/text",
        )
        return jsonify(payload), 400
    if not safe_account_id(account_id):
        payload = _build_send_result(False, error="invalid_id", detail="account_id")
        return jsonify(payload), 400

    payload = {
        "account_id": account_id,
        "chat_id": chat_id,
        "text": text,
        "reply_to": reply_to,
    }
    resp = _enqueue_send_job(account_id, "text", chat_id, payload)
    if not resp.get("ok"):
        status = 429 if resp.get("error") == "queue_full" else 400
        return jsonify(resp), status
    return jsonify({"ok": True, "accepted": True, **resp}), 202


@app.post("/api/send/photo")
@require_api_access
def send_photo_route():
    data = request.get_json(silent=True) or {}
    account_id = str(data.get("account_id") or "").strip()
    chat_id = data.get("chat_id")
    file_path = str(data.get("file_path") or "").strip()
    url = str(data.get("url") or "").strip()
    caption = str(data.get("caption") or "").strip()

    if not account_id or chat_id is None or (not file_path and not url):
        payload = _build_send_result(False, error="missing_fields", detail="account_id/chat_id/url")
        return jsonify(payload), 400
    if not safe_account_id(account_id):
        payload = _build_send_result(False, error="invalid_id", detail="account_id")
        return jsonify(payload), 400

    if file_path:
        if not os.path.exists(file_path):
            payload = _build_send_result(False, error="file_not_found", detail="file_path")
            return jsonify(payload), 400
        if not _allowed_file_path(file_path):
            payload = _build_send_result(False, error="file_not_allowed", detail="file_path")
            return jsonify(payload), 400

    payload = {
        "account_id": account_id,
        "chat_id": chat_id,
        "file_path": file_path,
        "url": url,
        "caption": caption,
    }
    resp = _enqueue_send_job(account_id, "photo", chat_id, payload)
    if not resp.get("ok"):
        status = 429 if resp.get("error") == "queue_full" else 400
        return jsonify(resp), status
    return jsonify({"ok": True, "accepted": True, **resp}), 202


@app.post("/api/send/video")
@require_api_access
def send_video_route():
    data = request.get_json(silent=True) or {}
    account_id = str(data.get("account_id") or "").strip()
    chat_id = data.get("chat_id")
    file_path = str(data.get("file_path") or "").strip()
    url = str(data.get("url") or "").strip()
    caption = str(data.get("caption") or "").strip()
    streaming = bool(data.get("streaming", False))

    if not account_id or chat_id is None or (not file_path and not url):
        payload = _build_send_result(False, error="missing_fields", detail="account_id/chat_id/url")
        return jsonify(payload), 400
    if not safe_account_id(account_id):
        payload = _build_send_result(False, error="invalid_id", detail="account_id")
        return jsonify(payload), 400

    if file_path:
        if not os.path.exists(file_path):
            payload = _build_send_result(False, error="file_not_found", detail="file_path")
            return jsonify(payload), 400
        if not _allowed_file_path(file_path):
            payload = _build_send_result(False, error="file_not_allowed", detail="file_path")
            return jsonify(payload), 400

    payload = {
        "account_id": account_id,
        "chat_id": chat_id,
        "file_path": file_path,
        "url": url,
        "caption": caption,
        "streaming": streaming,
    }
    resp = _enqueue_send_job(account_id, "video", chat_id, payload)
    if not resp.get("ok"):
        status = 429 if resp.get("error") == "queue_full" else 400
        return jsonify(resp), status
    return jsonify({"ok": True, "accepted": True, **resp}), 202


@app.post("/api/send/file")
@require_api_access
def send_file_route():
    data = request.get_json(silent=True) or {}
    account_id = str(data.get("account_id") or "").strip()
    chat_id = data.get("chat_id")
    file_path = str(data.get("file_path") or "").strip()
    url = str(data.get("url") or "").strip()
    caption = str(data.get("caption") or "").strip()

    if not account_id or chat_id is None or (not file_path and not url):
        payload = _build_send_result(False, error="missing_fields", detail="account_id/chat_id/url")
        return jsonify(payload), 400
    if not safe_account_id(account_id):
        payload = _build_send_result(False, error="invalid_id", detail="account_id")
        return jsonify(payload), 400

    if file_path:
        if not os.path.exists(file_path):
            payload = _build_send_result(False, error="file_not_found", detail="file_path")
            return jsonify(payload), 400
        if not _allowed_file_path(file_path):
            payload = _build_send_result(False, error="file_not_allowed", detail="file_path")
            return jsonify(payload), 400

    payload = {
        "account_id": account_id,
        "chat_id": chat_id,
        "file_path": file_path,
        "url": url,
        "caption": caption,
    }
    resp = _enqueue_send_job(account_id, "file", chat_id, payload)
    if not resp.get("ok"):
        status = 429 if resp.get("error") == "queue_full" else 400
        return jsonify(resp), status
    return jsonify({"ok": True, "accepted": True, **resp}), 202


@app.post("/api/send/voice")
@require_api_access
def send_voice_route():
    data = request.get_json(silent=True) or {}
    account_id = str(data.get("account_id") or "").strip()
    chat_id = data.get("chat_id")
    file_path = str(data.get("file_path") or "").strip()
    url = str(data.get("url") or "").strip()
    reply_to = data.get("reply_to")

    if not account_id or chat_id is None or (not file_path and not url):
        payload = _build_send_result(False, error="missing_fields", detail="account_id/chat_id/url")
        return jsonify(payload), 400
    if not safe_account_id(account_id):
        payload = _build_send_result(False, error="invalid_id", detail="account_id")
        return jsonify(payload), 400

    if file_path:
        if not os.path.exists(file_path):
            payload = _build_send_result(False, error="file_not_found", detail="file_path")
            return jsonify(payload), 400
        if not _allowed_file_path(file_path):
            payload = _build_send_result(False, error="file_not_allowed", detail="file_path")
            return jsonify(payload), 400

    payload = {
        "account_id": account_id,
        "chat_id": chat_id,
        "file_path": file_path,
        "url": url,
        "reply_to": reply_to,
    }
    resp = _enqueue_send_job(account_id, "voice", chat_id, payload)
    if not resp.get("ok"):
        status = 429 if resp.get("error") == "queue_full" else 400
        return jsonify(resp), status
    return jsonify({"ok": True, "accepted": True, **resp}), 202


@app.get("/api/send/queue")
@require_api_access
def send_queue_overview_route():
    items = []
    with _send_db_lock:
        conn = _db_connect()
        try:
            rows = conn.execute(
                "SELECT DISTINCT account_id FROM send_accounts UNION SELECT DISTINCT account_id FROM send_jobs"
            ).fetchall()
            account_ids = [row["account_id"] for row in rows]
        finally:
            conn.close()

    now = now_epoch()
    for account_id in account_ids:
        counts = db_counts_by_status(account_id)
        state = db_get_account_state(account_id)
        paused_until = int(state.get("paused_until") or 0)
        paused = bool(paused_until and now < paused_until)
        items.append({
            "account_id": account_id,
            "pending_count": int(counts.get("PENDING") or 0),
            "sending_count": int(counts.get("SENDING") or 0),
            "paused": paused,
            "paused_until": paused_until,
            "pause_remaining_sec": max(0, paused_until - now),
            "last_ok_at": state.get("last_ok_at"),
            "last_error": state.get("last_error"),
            "last_error_at": state.get("last_error_at"),
            "last_send_at": state.get("last_send_at"),
        })

    return jsonify({"ok": True, "items": items, "count": len(items)})


@app.get("/api/send/queue/<account_id>")
@require_api_access
def send_queue_account_route(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400
    try:
        limit = int(request.args.get("limit", "50"))
    except Exception:
        limit = 50
    limit = max(1, min(500, limit))

    jobs = db_list_jobs(account_id, limit=limit)
    items = []
    for j in jobs:
        items.append({
            "job_id": j.get("job_id"),
            "type": j.get("type"),
            "chat_id": j.get("chat_id"),
            "status": j.get("status"),
            "created_at": j.get("created_at"),
            "updated_at": j.get("updated_at"),
            "attempts": j.get("attempts"),
            "error": j.get("error"),
            "detail": j.get("detail"),
            "floodwait_seconds": j.get("floodwait_seconds"),
        })
    return jsonify({"ok": True, "account_id": account_id, "items": items, "count": len(items)})


@app.get("/api/send/queue/all")
@require_api_access
def send_queue_all_route():
    try:
        limit = int(request.args.get("limit", "200"))
    except Exception:
        limit = 200
    limit = max(1, min(2000, limit))

    jobs = db_list_all_jobs(limit=limit)
    items = []
    for j in jobs:
        items.append({
            "job_id": j.get("job_id"),
            "account_id": j.get("account_id"),
            "type": j.get("type"),
            "chat_id": j.get("chat_id"),
            "status": j.get("status"),
            "created_at": j.get("created_at"),
            "updated_at": j.get("updated_at"),
            "attempts": j.get("attempts"),
            "error": j.get("error"),
            "detail": j.get("detail"),
            "floodwait_seconds": j.get("floodwait_seconds"),
        })
    return jsonify({"ok": True, "items": items, "count": len(items)})


@app.get("/api/send/jobs/<job_id>")
@require_api_access
def send_job_detail_route(job_id: str):
    job = db_get_job(job_id)
    if not job:
        return jsonify({"ok": False, "error": "not_found"}), 404
    payload = job.get("payload_json")
    result = job.get("result_json")
    try:
        payload = json.loads(payload) if payload else None
    except Exception:
        payload = payload
    try:
        result = json.loads(result) if result else None
    except Exception:
        result = result
    job["payload_json"] = payload
    job["result_json"] = result
    return jsonify({"ok": True, "job": job})

@app.get("/api/accounts/<account_id>/status")
@require_api_access
def tg_status(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    acc = read_account(account_id)
    if not acc:
        return jsonify({"ok": False, "error": "not_found"}), 404

    # Se estÃ¡ em login pendente, devolve o step
    with tg_state_lock:
        st = tg_login_state.get(account_id)
        if st:
            payload = {
                "ok": True,
                "authorized": False,
                "session_exists": os.path.exists(_resolve_session_path(account_id, acc)),
                "step": st.get("step", "code_sent")
            }
            payload.update(_listener_status_payload(account_id))
            payload.update(_webhook_status_payload())
            return jsonify(payload)

    api_id = acc.get("api_id")
    api_hash = str(acc.get("api_hash") or "").strip()
    if api_id and api_hash:
        try:
            api_id_int = int(api_id)
        except Exception:
            api_id_int = None
        if api_id_int:
            try:
                resp = _run_coro(_tg_status_check(account_id, api_id_int, api_hash), timeout=40)
                payload = dict(resp)
                payload.update(_listener_status_payload(account_id))
                payload.update(_webhook_status_payload())
                return jsonify(payload)
            except Exception as e:
                payload = {"ok": False, "error": "status_check_failed", "detail": str(e)}
                payload.update(_listener_status_payload(account_id))
                payload.update(_webhook_status_payload())
                return jsonify(payload), 500

    # Fallback: sem credenciais, so diz se session existe
    payload = {
        "ok": True,
        "authorized": False,
        "session_exists": os.path.exists(_resolve_session_path(account_id, acc)),
        "step": None
    }
    payload.update(_listener_status_payload(account_id))
    payload.update(_webhook_status_payload())
    return jsonify(payload)


@app.get("/api/accounts/<account_id>/health")
@require_api_access
def account_health_route(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400
    force = str(request.args.get("force", "")).lower() in ("1", "true", "yes")
    payload = _health_check_account(account_id, force=force)
    return jsonify(payload), (200 if payload.get("ok") else 404)


@app.get("/api/health")
@require_api_access
def api_health_route():
    force = str(request.args.get("force", "")).lower() in ("1", "true", "yes")
    items = []
    for acc in list_accounts():
        acc_id = acc.get("id")
        if not acc_id:
            continue
        items.append(_health_check_account(acc_id, force=force))
    return jsonify({
        "ok": True,
        "items": items,
        "count": len(items),
        "ttl_sec": HEALTH_TTL_SEC,
        "time": now_epoch(),
    })


@app.get("/api/listeners")
@require_api_access
def listeners_list_route():
    with _listener_lock:
        items = [
            {
                "account_id": acc_id,
                "started_at": info.get("started_at"),
                **_listener_stats_get(acc_id),
            }
            for acc_id, info in _listeners.items()
        ]
    return jsonify({"ok": True, "items": items, "count": len(items)})


@app.get("/api/media/<media_id>")
@require_api_access
def media_get_route(media_id: str):
    if not re.match(r"^[a-f0-9]{16,64}$", media_id or ""):
        if not media_id.startswith("store_"):
            return jsonify({"ok": False, "error": "invalid_media_id"}), 400
    if media_id.startswith("store_") and not re.match(r"^store_[a-f0-9]{40}$", media_id):
        return jsonify({"ok": False, "error": "invalid_media_id"}), 400
    item = _media_cache_get(media_id)
    if not item:
        return jsonify({"ok": False, "error": "not_found"}), 404
    path = item.get("path")
    if not path or not os.path.exists(path):
        _media_cache_drop(media_id)
        return jsonify({"ok": False, "error": "not_found"}), 404
    if media_id.startswith("store_") and _media_store_touch_on_use():
        if _media_store_path_safe(path):
            _touch(path)
    mime = item.get("mime") or "application/octet-stream"
    return send_file(path, mimetype=mime)


# =========================================================
# Webhook test
# =========================================================

# (LEGADO/GENÃ‰RICO) Teste manual: vocÃª passa { "url": "...", "payload": {...} }
@app.post("/api/webhook/test")
@require_api_access
def webhook_test_route():
    data = request.get_json(silent=True) or {}
    url = str(data.get("url", "")).strip()
    payload = data.get("payload", {})
    if payload is None:
        payload = {}

    job_id = enqueue_webhook(payload, url)
    return jsonify({"ok": True, "job_id": job_id})


# (NOVO) Teste por instÃ¢ncia: usa sessions/<account_id>.json -> webhook_url
@app.post("/api/accounts/<account_id>/webhook/test")
@require_api_access
def webhook_test_account_route(account_id: str):
    if not safe_account_id(account_id):
        return jsonify({"ok": False, "error": "invalid_id"}), 400

    acc = read_account(account_id)
    if not acc:
        return jsonify({"ok": False, "error": "account_not_found"}), 404

    url = str(acc.get("webhook_url", "")).strip()
    if not url:
        # Se nÃ£o tiver webhook definido, registra job "failed" para o painel enxergar
        job_id = uuid.uuid4().hex
        job = {
            "job_id": job_id,
            "created_at": now_epoch(),
            "status": "failed",
            "tries": 0,
            "last_error": "webhook_disabled_or_missing_url",
        }
        _store_webhook_job(job)
        return jsonify({"ok": True, "job": job}), 200

    payload = {
        "type": "test",
        "account_id": acc.get("id", account_id),
        "phone": acc.get("phone"),
        "fingerprint_id": acc.get("fingerprint_id"),
        "session_path": acc.get("session_path"),
        "created_at": acc.get("created_at"),
        "updated_at": acc.get("updated_at"),
        "timestamp": now_epoch(),
    }

    job_id = enqueue_webhook(payload, url)
    job = get_job(job_id) or {
        "job_id": job_id,
        "created_at": now_epoch(),
        "status": "queued",
        "tries": 0,
        "last_error": None,
    }

    # Retorno compatÃ­vel com o painel (ele lÃª job.job_id)
    return jsonify({
        "ok": True,
        "job": {
            "job_id": job_id,
            "created_at": job.get("created_at"),
            "status": job.get("status"),
            "tries": job.get("tries"),
            "last_error": job.get("last_error"),
        }
    }), 200


@app.get("/api/webhook/jobs/<job_id>")
@require_api_access
def webhook_job_route(job_id: str):
    job = get_job(job_id)
    if not job:
        return jsonify({"ok": False, "error": "not_found"}), 404
    return jsonify({
        "ok": True,
        "job": {
            "job_id": job.get("job_id"),
            "created_at": job.get("created_at"),
            "status": job.get("status"),
            "tries": job.get("tries"),
            "last_error": job.get("last_error"),
        }
    })


@app.get("/api/debug/logs")
@require_api_access
def debug_logs_route():
    with _debug_lock:
        items = list(_debug_logs)
    return jsonify({"ok": True, "items": items})


@app.get("/api/debug/queue")
@require_api_access
def debug_queue_route():
    snap = _queue_stats_snapshot()
    return jsonify({
        "ok": True,
        "queue_size": _listener_queue_qsize(),
        "listener_redis_count": snap.get("listener_redis_count"),
        "last_sent_at": snap.get("last_sent_at"),
        "last_error": snap.get("last_error"),
        "dead_letter_count": snap.get("dead_letter_count"),
    })


@app.get("/api/debug/media")
@require_api_access
def debug_media_route():
    media_dir = _media_dir_abs()
    ttl = _media_ttl_seconds()
    try:
        file_count = sum(1 for _ in os.scandir(media_dir) if _.is_file())
    except Exception:
        file_count = 0
    return jsonify({
        "ok": True,
        "cwd": os.getcwd(),
        "project_root": str(PROJECT_ROOT),
        "media_dir_abs": media_dir,
        "ttl_seconds": ttl,
        "gc_thread_alive": bool(_media_gc_thread.is_alive() if "_media_gc_thread" in globals() else False),
        "file_count": file_count,
    })


# =========================================================
# Run
# =========================================================
def run_server():
    cfg = load_config()
    host = cfg.get("server", {}).get("host", "0.0.0.0")
    port = int(cfg.get("server", {}).get("port", 5000))

    try:
        from waitress import serve
        serve(app, host=host, port=port, threads=8)
    except Exception:
        app.run(host=host, port=port, debug=False)


if __name__ == "__main__":
    run_server()


